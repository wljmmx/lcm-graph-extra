<script setup lang="ts">
/**
 * 性能监控 Dashboard（模块 1）。
 *
 * 布局（设计文档 4.1 节）：
 *   KPI 卡片行 → 时序图区（压力信号 / 检索延迟 / tier 分布）→ 状态面板区
 *
 * 数据获取（TanStack Query 轮询）：
 *   - health-latest  10s 轮询（KPI + 熔断 + memory 面板）
 *   - health-history 1min 轮询（时序图）
 *   - agent-status   30s 轮询（OpenClaw host）
 *
 * 降级处理：memory 为 null → memory 面板显示"插件未响应"；
 *          db 为 null / 历史空 → KPI与时序图显示"无历史数据"；
 *          agent.error → 警告提示。
 */
import { computed, ref, h, watch, onMounted, onBeforeUnmount } from 'vue';
import { useQuery, useQueryClient } from '@tanstack/vue-query';
import { useRouter, useRoute } from 'vue-router';
import {
  NGrid,
  NGi,
  NCard,
  NEmpty,
  NTag,
  NDescriptions,
  NDescriptionsItem,
  NAlert,
  NSpace,
  NSpin,
  NTabs,
  NTabPane,
  NSelect,
  NProgress,
  NTable,
  NDivider,
  NButton,
  NPopconfirm,
  useMessage,
} from 'naive-ui';
import EChart from '../components/EChart.vue';
import KpiCard from '../components/KpiCard.vue';
import StatusIndicator from '../components/StatusIndicator.vue';
import MoaStatusBadge from '../components/MoaStatusBadge.vue';
import {
  fetchHealthLatest,
  fetchHealthHistory,
  fetchAgentStatus,
  fetchGraphHealth,
  type HealthSnapshot,
  type DashboardSnapshot,
  type AgentStatus,
  type GraphHealthResponse,
} from '../api/health';
import { formatTime, formatTimeWithSeconds, formatBucketLabel, bucketKeyBySize, timeRangeToMs, timeRangeLabel, bucketSizeLabel, type TimeRange, type BucketSize } from '../utils/format';
import { fetchMoaPerformance, type MoaPerformanceData } from '../api/moa';
import { invokeResetBreaker } from '../api/maintain';
import {
  fetchGmProHealth,
  fetchGmProTop,
  fetchGmProDirtyNodes,
  fetchGmProCommunities,
  fetchGmProUsage,
  fetchGmProAutoTunerState,
  fetchGmProServices,
  fetchGmProDoctor,
  formatGmProDoctorHint,
  fetchGmProAssociationMatrixState,
  postGmProAssociationMatrixSave,
  postGmProAssociationMatrixLoad,
  type GmProCommunitySummary,
  type GmProServiceStatus,
} from '../api/gm-pro';
import AssociationMatrixCard from '../components/monitor/AssociationMatrixCard.vue';
import { useTheme } from '../composables/useTheme';

const { isDark } = useTheme();
const message = useMessage();

// UX-14: 窄屏检测，用于自适应图表 X 轴标签旋转
const windowWidth = ref(typeof window !== 'undefined' ? window.innerWidth : 1024);
function onResize() { windowWidth.value = window.innerWidth; }
onMounted(() => { window.addEventListener('resize', onResize); });
onBeforeUnmount(() => { window.removeEventListener('resize', onResize); });

// ===== 图表颜色语义常量（跟随主题切换） =====
// 统一语义：蓝=主数据，绿=成功/正向，橙=警告/阈值，红=危险/反向，紫=辅助
const CHART = computed(() => ({
  primary: isDark.value ? '#4098fc' : '#2080f0',
  success: isDark.value ? '#36ad6a' : '#18a058',
  warning: isDark.value ? '#fcb040' : '#f0a020',
  danger:  isDark.value ? '#de5169' : '#d03050',
  info:    isDark.value ? '#9270ed' : '#7c3aed',
  neutral: isDark.value ? '#a8abb2' : '#909399',
}));

// ===== 时序图：时间范围 + 统计粒度（两个独立维度） =====
// 时间范围：筛选最近 N 时间内的数据（1h/1d/1w/1m）
// 统计粒度：数据点如何分桶聚合（实时/1min/5min/10min/1h）
const timeRangeOptions = [
  { label: '最近 1 小时', value: '1h' as TimeRange },
  { label: '最近 1 天', value: '1d' as TimeRange },
  { label: '最近 1 周', value: '1w' as TimeRange },
  { label: '最近 1 月', value: '1m' as TimeRange },
];
const bucketSizeOptions = [
  { label: '实时记录', value: 'raw' as BucketSize },
  { label: '1 分钟', value: '1min' as BucketSize },
  { label: '5 分钟', value: '5min' as BucketSize },
  { label: '10 分钟', value: '10min' as BucketSize },
  { label: '1 小时', value: '1h' as BucketSize },
];
const timeRange = ref<TimeRange>('1h');
const bucketSize = ref<BucketSize>('raw');

// ===== 复杂度趋势：聚合维度 + 时间范围 =====
type ComplexityAggregation = 'raw' | 'hourly' | 'daily';
const complexityAggregation = ref<ComplexityAggregation>('raw');
const complexityTimeRange = ref<TimeRange>('1h');
const complexityAggOptions = [
  { label: '实时记录', value: 'raw' as ComplexityAggregation },
  { label: '按小时', value: 'hourly' as ComplexityAggregation },
  { label: '按天', value: 'daily' as ComplexityAggregation },
];
const complexityTimeRangeOptions = [
  { label: '最近 1 小时', value: '1h' as TimeRange },
  { label: '最近 1 天', value: '1d' as TimeRange },
  { label: '最近 1 周', value: '1w' as TimeRange },
];

// 根据时间范围决定拉取的数据量（n 条原始点，5min 心跳 = 288/天）
// 多取 ~10% 余量，前端再按 timestamp 精确过滤
const historyN = computed(() => {
  switch (timeRange.value) {
    case '1h': return 24;       // 12 点 + 余量
    case '1d': return 300;      // 288 + 余量
    case '1w': return 2100;     // 2016 + 余量
    case '1m': return 8640;     // 30 天上限
    default: return 24;
  }
});

// ===== 数据获取（轮询） =====
// E1 修复: 解构 isError，HTTP 错误不再被静默吞掉
const { data: latestData, isLoading: latestLoading, isError: latestIsError } = useQuery({
  queryKey: ['health-latest'],
  queryFn: fetchHealthLatest,
  refetchInterval: 10_000,
  staleTime: 5_000, // PERF-8: 5s 内数据视为新鲜，避免重复请求
});
const { data: historyData, isLoading: historyLoading, isError: historyIsError } = useQuery({
  queryKey: ['health-history', historyN], // 粒度变化时重新拉取
  queryFn: () => fetchHealthHistory(historyN.value),
  refetchInterval: 60_000,
  staleTime: 30_000, // PERF-8: 30s 内数据视为新鲜
});
const { data: agentData, isLoading: agentLoading, isError: agentIsError } = useQuery({
  queryKey: ['agent-status'],
  queryFn: fetchAgentStatus,
  refetchInterval: 30_000,
  staleTime: 15_000, // PERF-8: 15s 内数据视为新鲜
});
// G-5: 图谱健康（gm-pro getGraphHealth，降级到本地 graphAdapter 推断）
const { data: graphHealthData, isLoading: graphHealthLoading, isError: graphHealthIsError } = useQuery({
  queryKey: ['graph-health'],
  queryFn: fetchGraphHealth,
  refetchInterval: 30_000,
  staleTime: 15_000, // PERF-8: 15s 内数据视为新鲜
});

// G-5.1: gm-pro 健康报告（增强图谱健康卡片）
const { data: gmProHealthRes } = useQuery({
  queryKey: ['gm-pro-health'],
  queryFn: fetchGmProHealth,
  refetchInterval: 30_000,
  staleTime: 15_000,
});
const gmProHealth = computed(() => gmProHealthRes.value?.ok ? (gmProHealthRes.value.data ?? null) : null);

// G-5.2: gm-pro Top 10 节点（用于柱状图）
const { data: gmProTop10Res } = useQuery({
  queryKey: ['gm-pro-top10'],
  queryFn: () => fetchGmProTop(10),
  refetchInterval: 60_000,
  staleTime: 30_000,
});
const gmProTop10 = computed(() => gmProTop10Res.value?.ok ? (gmProTop10Res.value.data?.nodes ?? []) : []);

// G-5.3: gm-pro 脏节点监控
const { data: gmProDirtyRes } = useQuery({
  queryKey: ['gm-pro-dirty-nodes'],
  queryFn: fetchGmProDirtyNodes,
  refetchInterval: 60_000,
  staleTime: 30_000,
});
const gmProDirty = computed(() => gmProDirtyRes.value?.ok ? (gmProDirtyRes.value.data ?? null) : null);

// G-5.4: gm-pro 社区概览
const { data: gmProCommunitiesRes } = useQuery({
  queryKey: ['gm-pro-communities'],
  queryFn: fetchGmProCommunities,
  refetchInterval: 120_000,
  staleTime: 60_000,
});
const gmProCommunities = computed<GmProCommunitySummary[]>(() =>
  gmProCommunitiesRes.value?.ok ? (gmProCommunitiesRes.value.data?.summaries ?? []) : [],
);

// 社区总数：优先取社区概览接口的 count，回退到健康接口的 communities 数。
// 用于"有社区但暂无摘要"时回退展示，避免与健康概览社区数=1 相矛盾的空态。
const gmProCommunityCount = computed<number>(() => {
  const fromSummaries = gmProCommunitiesRes.value?.ok ? (gmProCommunitiesRes.value.data?.count ?? 0) : 0;
  if (fromSummaries > 0) return fromSummaries;
  // 健康接口的 communities 字段（健康概览已展示）
  return gmProHealth?.communities ?? 0;
});

// G-5.5: gm-pro LLM Token 用量
const { data: gmProUsageRes } = useQuery({
  queryKey: ['gm-pro-usage'],
  queryFn: fetchGmProUsage,
  refetchInterval: 60_000,
  staleTime: 30_000,
});
const gmProUsage = computed(() => gmProUsageRes.value?.ok ? (gmProUsageRes.value.data ?? null) : null);

// G-5.6: gm-pro AutoTuner 状态
const { data: gmProTunerRes } = useQuery({
  queryKey: ['gm-pro-auto-tuner'],
  queryFn: fetchGmProAutoTunerState,
  refetchInterval: 120_000,
  staleTime: 60_000,
});
const gmProTuner = computed(() => gmProTunerRes.value?.ok ? (gmProTunerRes.value.data ?? null) : null);

// G-5.7: gm-pro 服务状态总览
const { data: gmProServicesRes } = useQuery({
  queryKey: ['gm-pro-services'],
  queryFn: fetchGmProServices,
  refetchInterval: 60_000,
  staleTime: 30_000,
});
const gmProServices = computed<GmProServiceStatus | null>(() =>
  gmProServicesRes.value?.ok ? (gmProServicesRes.value.data ?? null) : null,
);

// G-5.8: gm-pro 系统诊断 (Doctor)
const { data: gmProDoctorRes } = useQuery({
  queryKey: ['gm-pro-doctor'],
  queryFn: fetchGmProDoctor,
  refetchInterval: 120_000,
  staleTime: 60_000,
});
const gmProDoctor = computed(() => gmProDoctorRes.value?.ok ? (gmProDoctorRes.value.data ?? null) : null);
// G-5.8: Doctor 空态提示按真实原因区分（401 / 不可达 / 其他），避免一律误报鉴权
const gmProDoctorHint = computed(() => {
  const res = gmProDoctorRes.value;
  const err = res && !res.ok ? String(res.error ?? '') : '';
  return err ? formatGmProDoctorHint(err) : '暂无诊断报告';
});

// G-5.8: Doctor 报告解析（/api/doctor 返回 checks[] 数组，非顶层 neo4j/llm 对象）
const gmProDoctorChecks = computed<any[]>(() => {
  const list = (gmProDoctor as any)?.checks;
  return Array.isArray(list) ? list : [];
});
const gmProDoctorSummary = computed<{ ok: number; warn: number; error: number; total: number }>(() => {
  const s = (gmProDoctor as any)?.summary;
  if (s && typeof s === 'object') return { ok: s.ok ?? 0, warn: s.warn ?? 0, error: s.error ?? 0, total: s.total ?? 0 };
  const checks = gmProDoctorChecks.value;
  return {
    ok: checks.filter((c) => c.status === 'ok').length,
    warn: checks.filter((c) => c.status === 'warn').length,
    error: checks.filter((c) => c.status === 'error').length,
    total: checks.length,
  };
});
const gmProDoctorAbnormalCount = computed(() => gmProDoctorSummary.value.error);
function doctorCheckTagType(s: string): 'success' | 'warning' | 'error' | 'default' {
  if (s === 'ok') return 'success';
  if (s === 'warn') return 'warning';
  if (s === 'error') return 'error';
  return 'default';
}
function doctorCheckLabel(s: string): string {
  if (s === 'ok') return '正常';
  if (s === 'warn') return '警告';
  if (s === 'error') return '异常';
  return s;
}

// G-5.9: gm-pro 关联矩阵 M 状态
const { data: gmProAmRes, isFetching: gmProAmFetching, isError: gmProAmError } = useQuery({
  queryKey: ['gm-pro-association-matrix'],
  queryFn: fetchGmProAssociationMatrixState,
  refetchInterval: 120_000,
  staleTime: 60_000,
});
const gmProAm = computed(() => gmProAmRes.value?.ok ? (gmProAmRes.value.data ?? null) : null);

// G-5.9.1: 关联矩阵 M 持久化操作（save / load），成功后刷新状态
const queryClient = useQueryClient();
const amActing = ref(false);
async function handleAmSave(): Promise<void> {
  if (amActing.value) return;
  amActing.value = true;
  try {
    const res = await postGmProAssociationMatrixSave();
    if (res.ok) {
      message.success(`关联矩阵 M 已保存${res.data?.path ? ` → ${res.data.path}` : ''}`);
    } else {
      message.error(`保存失败: ${res.error || '未知错误'}`);
    }
  } catch (err: any) {
    message.error(`保存失败: ${err?.message || String(err)}`);
  } finally {
    amActing.value = false;
    queryClient.invalidateQueries({ queryKey: ['gm-pro-association-matrix'] });
  }
}
async function handleAmLoad(): Promise<void> {
  if (amActing.value) return;
  amActing.value = true;
  try {
    const res = await postGmProAssociationMatrixLoad();
    if (res.ok) {
      message.success('关联矩阵 M 已从磁盘加载');
    } else {
      message.error(`加载失败: ${res.error || '未知错误'}`);
    }
  } catch (err: any) {
    message.error(`加载失败: ${err?.message || String(err)}`);
  } finally {
    amActing.value = false;
    queryClient.invalidateQueries({ queryKey: ['gm-pro-association-matrix'] });
  }
}

// MoA 性能数据（30s 轮询）
const { data: moaPerfData, isLoading: moaPerfLoading } = useQuery({
  queryKey: ['moa-performance'],
  queryFn: fetchMoaPerformance,
  refetchInterval: 30_000,
  staleTime: 15_000, // PERF-8: 15s 内数据视为新鲜
});

const moaPerf = computed<MoaPerformanceData | null>(() => moaPerfData.value?.data ?? null);

// ===== 派生数据 =====
const db = computed<HealthSnapshot | null>(() => latestData.value?.db ?? null);
const memory = computed<DashboardSnapshot | null>(
  () => latestData.value?.memory ?? null,
);
// DB 返回 DESC（最新在前），时序图需要 ASC（最旧在前）
// v2.2.4: 按时间范围精确过滤（historyN 只是近似拉取量，这里按 timestamp 严格筛选）
const rawHistoryAsc = computed<HealthSnapshot[]>(() => {
  const snaps = historyData.value?.snapshots ?? [];
  if (snaps.length === 0) return [];
  const rangeMs = timeRangeToMs(timeRange.value);
  const cutoff = Date.now() - rangeMs;
  return snaps.filter((s) => s.timestamp >= cutoff).reverse();
});

/**
 * 按统计粒度聚合历史快照。
 *
 * 聚合规则（不同指标用不同聚合函数）：
 * - pendingMessages / summaryFragments → max（峰值更有意义）
 * - maxTokenRatio → avg（平均占用）
 * - lastAssembleMs / lastL2Ms / lastL3Ms / lastL4Ms → avg（平均延迟）
 * - tierLow / tierMedium / tierHigh → sum（累计次数）
 * - cbFailures → max
 * - timestamp → 桶内最新时间戳（用于 X 轴标签）
 *
 * raw 粒度直接返回原始数据（实时记录累计，不聚合）。
 */
const historyAsc = computed<HealthSnapshot[]>(() => {
  const snaps = rawHistoryAsc.value;
  const size = bucketSize.value;
  if (size === 'raw' || snaps.length === 0) return snaps;

  // 按统计粒度分桶
  const buckets = new Map<string, HealthSnapshot[]>();
  for (const s of snaps) {
    const key = bucketKeyBySize(s.timestamp, size);
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key)!.push(s);
  }

  // 聚合每个桶
  const result: HealthSnapshot[] = [];
  for (const [, group] of buckets) {
    if (group.length === 0) continue;
    const avg = (field: keyof HealthSnapshot): number => {
      const vals = group.map((s) => Number(s[field] ?? 0)).filter((v) => !isNaN(v));
      return vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
    };
    const max = (field: keyof HealthSnapshot): number => {
      const vals = group.map((s) => Number(s[field] ?? 0)).filter((v) => !isNaN(v));
      return vals.length > 0 ? Math.max(...vals) : 0;
    };
    const sum = (field: keyof HealthSnapshot): number => {
      const vals = group.map((s) => Number(s[field] ?? 0)).filter((v) => !isNaN(v));
      return vals.reduce((a, b) => a + b, 0);
    };
    // 取桶内最新时间戳作为标签时间
    const latestTs = Math.max(...group.map((s) => s.timestamp));
    result.push({
      timestamp: latestTs,
      pendingMessages: Math.round(max('pendingMessages')),
      summaryFragments: Math.round(max('summaryFragments')),
      maxTokenRatio: Math.round(avg('maxTokenRatio') * 1000) / 1000,
      cbLcmAvailable: group.every((s) => s.cbLcmAvailable),
      cbQmdAvailable: group.every((s) => s.cbQmdAvailable),
      cbNeo4jAvailable: group.every((s) => s.cbNeo4jAvailable),
      cbLcmFailures: Math.round(max('cbLcmFailures')),
      cbQmdFailures: Math.round(max('cbQmdFailures')),
      cbNeo4jFailures: Math.round(max('cbNeo4jFailures')),
      lastAssembleMs: Math.round(avg('lastAssembleMs')),
      lastL2Ms: Math.round(avg('lastL2Ms')),
      lastL3Ms: Math.round(avg('lastL3Ms')),
      lastL4Ms: Math.round(avg('lastL4Ms')),
      pendingExperienceCount: Math.round(max('pendingExperienceCount')),
      distilledExperienceCount: Math.round(max('distilledExperienceCount')),
      tierLow: Math.round(sum('tierLow')),
      tierMedium: Math.round(sum('tierMedium')),
      tierHigh: Math.round(sum('tierHigh')),
    });
  }
  return result;
});
const agent = computed<AgentStatus | null>(() => agentData.value ?? null);
const graphHealth = computed<GraphHealthResponse | null>(
  () => graphHealthData.value ?? null,
);

// G-5: 图谱健康 status → tag type 映射
const graphHealthTagType = computed<'success' | 'warning' | 'error' | 'default'>(() => {
  const s = graphHealth.value?.status;
  if (s === 'healthy') return 'success';
  if (s === 'degraded') return 'warning';
  if (s === 'unhealthy') return 'error';
  return 'default';
});
const graphHealthSourceTagType = computed<'success' | 'warning' | 'default'>(() => {
  const s = graphHealth.value?.source;
  if (s === 'gm-pro') return 'success';
  if (s === 'local') return 'warning';
  return 'default';
});

// G-5.1: Top 10 PageRank 柱状图 ECharts option
const top10ChartOption = computed(() => {
  const nodes = gmProTop10.value;
  if (!nodes.length) return null;
  return {
    tooltip: { trigger: 'axis' as const, axisPointer: { type: 'shadow' as const } },
    grid: { left: 12, right: 24, top: 8, bottom: 4, containLabel: true },
    xAxis: {
      type: 'value' as const,
      axisLabel: { fontSize: 10, color: isDark.value ? '#aaa' : '#666' },
      splitLine: { show: false },
    },
    yAxis: {
      type: 'category' as const,
      data: nodes.map((n: any) => n.name?.slice(0, 20) ?? n.id?.slice(0, 12) ?? '—').reverse(),
      axisLabel: { fontSize: 10, color: isDark.value ? '#ccc' : '#333' },
      inverse: true,
    },
    series: [{
      type: 'bar',
      data: nodes.map((n: any) => n.pagerank ?? 0).reverse(),
      barWidth: 14,
      itemStyle: {
        borderRadius: [0, 3, 3, 0],
        color: isDark.value ? '#66b1ff' : '#409eff',
      },
    }],
  };
});

// ===== KPI 值（db 为 null 时显示 "—"） =====
const kpiPending = computed<number | string>(() =>
  db.value ? db.value.pendingMessages : '—',
);
const kpiTokenRatio = computed<number | string>(() =>
  db.value ? Math.round(db.value.maxTokenRatio * 1000) / 10 : '—',
);
const kpiAssembleMs = computed<number | string>(() =>
  db.value ? db.value.lastAssembleMs : '—',
);
const kpiCbFailures = computed<number | string>(() => {
  if (!db.value) return '—';
  return db.value.cbLcmFailures + db.value.cbQmdFailures + db.value.cbNeo4jFailures;
});

// ===== P3-13: KPI 趋势对比（较上一次快照的变化量） =====
const kpiTrend = computed(() => {
  const prev = historyAsc.value.length >= 2 ? historyAsc.value[historyAsc.value.length - 2] : null;
  const cur = db.value;
  if (!prev || !cur) return { pending: 0, tokenRatio: 0, assembleMs: 0, cbFailures: 0 };
  return {
    pending: cur.pendingMessages - prev.pendingMessages,
    tokenRatio: Math.round((cur.maxTokenRatio - prev.maxTokenRatio) * 1000) / 10,
    assembleMs: cur.lastAssembleMs - prev.lastAssembleMs,
    cbFailures: (cur.cbLcmFailures + cur.cbQmdFailures + cur.cbNeo4jFailures) -
      (prev.cbLcmFailures + prev.cbQmdFailures + prev.cbNeo4jFailures),
  };
});

// =====// 最近更新时间（HH:mm:ss）
const lastUpdated = computed(() => formatTimeWithSeconds(db.value?.timestamp));

// UX-2: 全局刷新状态指示器
const isAnyLoading = computed(() => latestLoading.value || historyLoading.value || agentLoading.value || graphHealthLoading.value || moaPerfLoading.value);
const isAnyError = computed(() => latestIsError.value || historyIsError.value || agentIsError.value || graphHealthIsError.value);
const refreshStatus = computed(() => {
  if (isAnyError.value) return { label: '部分服务异常', type: 'error' as const };
  if (isAnyLoading.value && !latestData.value) return { label: '正在加载…', type: 'info' as const };
  if (isAnyLoading.value) return { label: '刷新中…', type: 'default' as const };
  return { label: '就绪', type: 'success' as const };
});

// ===== P1-2: 熔断器状态（来自 healthLatest，NTag 颜色标记） =====
// 颜色规则：available=绿 / failures>0=红 / 否则灰
interface CircuitBreakerItem {
  key: string;
  label: string;
  available: boolean;
  failures: number;
  tagType: 'success' | 'error' | 'default';
}
const circuitBreakerItems = computed<CircuitBreakerItem[]>(() => {
  const d = db.value;
  if (!d) return [];
  const build = (
    key: string,
    label: string,
    available: boolean,
    failures: number,
  ): CircuitBreakerItem => ({
    key,
    label,
    available,
    failures,
    // available 优先绿；否则 failures>0 红；否则灰
    tagType: available ? 'success' : failures > 0 ? 'error' : 'default',
  });
  return [
    build('lcm', 'LCM', d.cbLcmAvailable, d.cbLcmFailures),
    build('qmd', 'QMD', d.cbQmdAvailable, d.cbQmdFailures),
    build('neo4j', 'Neo4j', d.cbNeo4jAvailable, d.cbNeo4jFailures),
  ];
});

// ===== P1-2: 熔断器子系统统计（成功率 + 开合次数） =====
interface CbSubsystemStat {
  key: string;
  label: string;
  available: boolean;
  failures: number;
  /** 历史快照中可用的比例（成功率） */
  successRate: number;
  /** 历史快照中状态变化的次数（开合次数） */
  openCloseCount: number;
  tagType: 'success' | 'error' | 'default';
}

const cbSubsystemStats = computed<CbSubsystemStat[]>(() => {
  const d = db.value;
  if (!d) return [];

  // v2.4.0: 优先使用全局累计计数器（跨窗口持久化），fallback 到历史快照计算。
  // 全局累计计数器来自 memory.health.latest，包含 cbLcmTotalChecks/cbLcmSuccessCount 等字段。
  const memSnapshot = memory.value?.health?.latest;
  const hasGlobalCumulative = memSnapshot != null
    && typeof memSnapshot.cbLcmTotalChecks === 'number'
    && typeof memSnapshot.cbLcmSuccessCount === 'number';

  const calc = (key: string, label: string, currentAvailable: boolean, currentFailures: number) => {
    let successRate: number;
    let transitions: number;

    if (hasGlobalCumulative) {
      // 使用全局累计计数器
      let totalChecks: number;
      let successCount: number;
      let transCount: number;
      if (key === 'lcm') {
        totalChecks = memSnapshot!.cbLcmTotalChecks ?? 0;
        successCount = memSnapshot!.cbLcmSuccessCount ?? 0;
        transCount = memSnapshot!.cbLcmTransitions ?? 0;
      } else if (key === 'qmd') {
        totalChecks = memSnapshot!.cbQmdTotalChecks ?? 0;
        successCount = memSnapshot!.cbQmdSuccessCount ?? 0;
        transCount = memSnapshot!.cbQmdTransitions ?? 0;
      } else {
        totalChecks = memSnapshot!.cbNeo4jTotalChecks ?? 0;
        successCount = memSnapshot!.cbNeo4jSuccessCount ?? 0;
        transCount = memSnapshot!.cbNeo4jTransitions ?? 0;
      }
      successRate = totalChecks > 0 ? Math.round((successCount / totalChecks) * 1000) / 10 : 100;
      transitions = transCount;
    } else {
      // Fallback: 从历史快照计算（原有逻辑）
      const history = rawHistoryAsc.value;
      let availableCount = 0;
      let totalCount = 0;
      let trans = 0;
      let prevState: boolean | null = null;

      for (const snap of history) {
        let available: boolean;
        if (key === 'lcm') available = snap.cbLcmAvailable;
        else if (key === 'qmd') available = snap.cbQmdAvailable;
        else available = snap.cbNeo4jAvailable;

        if (available) availableCount++;
        totalCount++;

        if (prevState !== null && prevState !== available) {
          trans++;
        }
        prevState = available;
      }
      successRate = totalCount > 0 ? Math.round((availableCount / totalCount) * 1000) / 10 : 100;
      transitions = trans;
    }

    const tagType: 'success' | 'error' | 'default' = currentAvailable ? 'success' : currentFailures > 0 ? 'error' : 'default';
    return { key, label, available: currentAvailable, failures: currentFailures, successRate, openCloseCount: transitions, tagType };
  };

  const result = [
    calc('lcm', 'LCM', d.cbLcmAvailable, d.cbLcmFailures),
    calc('qmd', 'QMD', d.cbQmdAvailable, d.cbQmdFailures),
    calc('neo4j', 'Neo4j', d.cbNeo4jAvailable, d.cbNeo4jFailures),
  ];
  _cbStatsCache = { key: `${d.timestamp}:${hasGlobalCumulative ? 'global' : 'history'}`, data: result };
  return result;
});

// PERF-4: 熔断器统计缓存
let _cbStatsCache: { key: string; data: CbSubsystemStat[] } | null = null;

// UX-7: 熔断器重置（带二次确认）
const resettingBreaker = ref<string | null>(null);
async function handleResetBreaker(name: string): Promise<void> {
  if (resettingBreaker.value) return;
  resettingBreaker.value = name;
  try {
    const res = await invokeResetBreaker(name);
    if (res.success) {
      message.success(`熔断器 ${name.toUpperCase()} 已重置`);
    } else {
      message.error(`重置失败: ${res.error || '未知错误'}`);
    }
  } catch (err: any) {
    message.error(`重置失败: ${err?.message || String(err)}`);
  } finally {
    resettingBreaker.value = null;
  }
}

// ===== P1-6: 当前压力 Tier 徽章 =====
// 根据 tierLow/tierMedium/tierHigh 值判断当前 tier（值最大的那个即为当前 tier）
type TierLevel = 'low' | 'medium' | 'high';
const currentTier = computed<TierLevel | null>(() => {
  const d = db.value;
  if (!d) return null;
  const low = d.tierLow ?? 0;
  const medium = d.tierMedium ?? 0;
  const high = d.tierHigh ?? 0;
  // 三项均为 0 时无法判断
  if (low === 0 && medium === 0 && high === 0) return null;
  if (high >= low && high >= medium) return 'high';
  if (medium >= low && medium >= high) return 'medium';
  return 'low';
});
const currentTierTagType = computed<'success' | 'warning' | 'error' | 'default'>(() => {
  switch (currentTier.value) {
    case 'low': return 'success';
    case 'medium': return 'warning';
    case 'high': return 'error';
    default: return 'default';
  }
});
const currentTierLabel = computed(() => {
  switch (currentTier.value) {
    case 'low': return 'Low';
    case 'medium': return 'Medium';
    case 'high': return 'High';
    default: return '—';
  }
});

// 当前快照 tier 分布占比（供 NProgress 三条展示）
const currentTierDistribution = computed(() => {
  const d = db.value;
  const low = d?.tierLow ?? 0;
  const medium = d?.tierMedium ?? 0;
  const high = d?.tierHigh ?? 0;
  const total = low + medium + high;
  return {
    low,
    medium,
    high,
    total,
    lowPct: total > 0 ? (low / total) * 100 : 0,
    mediumPct: total > 0 ? (medium / total) * 100 : 0,
    highPct: total > 0 ? (high / total) * 100 : 0,
  };
});

// ===== P1-6: 最近 10 次 tier 分布趋势（水平条形图） =====
interface TierTrendPoint {
  timestamp: number;
  low: number;
  medium: number;
  high: number;
  total: number;
  lowPct: number;
  mediumPct: number;
  highPct: number;
  dominant: TierLevel | null;
}

const TIER_TREND_STORAGE_KEY = 'dashboard-tier-trend';

/** 从 localStorage 加载持久化的 tier 趋势数据 */
function loadPersistedTierTrend(): TierTrendPoint[] {
  try {
    const raw = localStorage.getItem(TIER_TREND_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((p: any) => typeof p?.timestamp === 'number');
  } catch {
    return [];
  }
}

/** 持久化 tier 趋势数据到 localStorage */
function savePersistedTierTrend(points: TierTrendPoint[]): void {
  try {
    localStorage.setItem(TIER_TREND_STORAGE_KEY, JSON.stringify(points));
  } catch { /* localStorage 不可用或满，静默忽略 */ }
}

/** 从 historyAsc 快照构建 TierTrendPoint */
function snapshotToTierPoint(s: HealthSnapshot): TierTrendPoint {
  const low = s.tierLow ?? 0;
  const medium = s.tierMedium ?? 0;
  const high = s.tierHigh ?? 0;
  const total = low + medium + high;
  const pct = (v: number): number => (total > 0 ? (v / total) * 100 : 0);
  let dominant: TierLevel | null = null;
  if (total > 0) {
    if (high >= low && high >= medium) dominant = 'high';
    else if (medium >= low && medium >= high) dominant = 'medium';
    else dominant = 'low';
  }
  return {
    timestamp: s.timestamp,
    low,
    medium,
    high,
    total,
    lowPct: pct(low),
    mediumPct: pct(medium),
    highPct: pct(high),
    dominant,
  };
}

// v2.3.1: 持久化 tier 趋势数据，解决"经常只统计到几次就清零重新统计"问题。
// 修复前：recentTierTrend 是 computed，完全依赖 historyAsc（API 返回的快照）。
// 当 timeRange='1h' 时 historyN 仅 24 条，且 API 可能返回空或少量数据，
// 导致图表显示点数不足或清零。修复后：使用 localStorage 持久化，跨轮询周期
// 累积数据，合并去重（按 timestamp），始终保留最近 10 个唯一点。
const persistedTierTrend = ref<TierTrendPoint[]>(loadPersistedTierTrend());

// 监听 historyAsc 变化，将新快照合并到持久化存储
watch(historyAsc, (snaps) => {
  if (snaps.length === 0) return;
  // 将当前持久化数据与新快照合并，按 timestamp 去重
  const existingMap = new Map<number, TierTrendPoint>();
  for (const p of persistedTierTrend.value) {
    existingMap.set(p.timestamp, p);
  }
  // 用新数据覆盖同 timestamp 的点
  for (const s of snaps) {
    // 只保留最近 1 小时内的数据点，避免跨天数据混淆
    const ageMs = Date.now() - s.timestamp;
    if (ageMs > 2 * 60 * 60 * 1000) continue; // 超过 2 小时的旧数据丢弃
    existingMap.set(s.timestamp, snapshotToTierPoint(s));
  }
  // 按时间倒序排列，取最近 10 个
  const merged = [...existingMap.values()]
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 10);
  persistedTierTrend.value = merged;
  savePersistedTierTrend(merged);
}, { immediate: false });

// 模板使用的 tier 趋势（优先持久化，fallback 到 computed）
const recentTierTrend = computed<TierTrendPoint[]>(() => {
  // 如果有持久化数据，直接使用
  if (persistedTierTrend.value.length > 0) return persistedTierTrend.value;
  // fallback：从当前 historyAsc 构建
  const snaps = historyAsc.value.slice(-10);
  return snaps.map(snapshotToTierPoint);
});

// ===== 时序图 X 轴标签（按统计粒度格式化） =====
const timeLabels = computed(() =>
  historyAsc.value.map((s) => formatBucketLabel(s.timestamp, bucketSize.value)),
);

// 选择器右侧提示：当前时间范围 + 统计粒度 + 数据点数
const rangeBucketHint = computed(() => {
  const pts = historyAsc.value.length;
  const range = timeRangeLabel(timeRange.value);
  const bucket = bucketSizeLabel(bucketSize.value);
  let hint = `${range} · 粒度 ${bucket} · ${pts} 个数据点`;
  if (pts > 2000) hint += '（点数过多，建议选更粗的统计粒度）';
  return hint;
});

// UX-14: 窄屏图表 X 轴标签自适应旋转角度
const xAxisLabelRotate = computed(() => windowWidth.value < 768 ? 45 : 0);

// 时序图1：压力信号（双 Y 轴，左：数量，右：比率 0-1）
const pressureOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  legend: { data: ['待处理消息', '摘要片段', 'Token 占用比'] },
  grid: { left: 56, right: 64, top: 36, bottom: 28 },
  xAxis: { type: 'category', data: timeLabels.value, boundaryGap: false, axisLabel: { rotate: xAxisLabelRotate.value } },
  yAxis: [
    { type: 'value', name: '数量', position: 'left' },
    { type: 'value', name: '比率', position: 'right', min: 0, max: 1 },
  ],
  series: [
    {
      name: '待处理消息',
      type: 'line',
      smooth: true,
      yAxisIndex: 0,
      data: historyAsc.value.map((s) => s.pendingMessages),
      lineStyle: { color: CHART.value.primary },
      itemStyle: { color: CHART.value.primary },
      symbol: 'circle',
      symbolSize: 4,
    },
    {
      name: '摘要片段',
      type: 'line',
      smooth: true,
      yAxisIndex: 0,
      data: historyAsc.value.map((s) => s.summaryFragments),
      lineStyle: { color: CHART.value.info, type: 'dashed' },
      itemStyle: { color: CHART.value.info },
      symbol: 'diamond',
      symbolSize: 4,
    },
    {
      name: 'Token 占用比',
      type: 'line',
      smooth: true,
      yAxisIndex: 1,
      data: historyAsc.value.map((s) => s.maxTokenRatio),
      lineStyle: { color: CHART.value.danger, type: 'dotted' },
      itemStyle: { color: CHART.value.danger },
      symbol: 'triangle',
      symbolSize: 4,
    },
  ],
}));

// 时序图2：检索延迟（Assemble 折线 + L2/L3/L4 独立柱）
// 修复重复累计 bug：原 4 项全部 stack:'latency' 堆叠，导致 Assemble(含L2/L3/L4) + L2 + L3 + L4
// 虚高。且 L2/L3/L4 为 Promise.all 真并行，堆叠相加物理意义错误。
// 改为：Assemble 折线（总耗时趋势）+ L2/L3/L4 独立柱（不堆叠，各层并行耗时对比）
const latencyOption = computed(() => ({
  tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
  legend: { data: ['Assemble', 'L2', 'L3', 'L4'] },
  grid: { left: 56, right: 20, top: 36, bottom: 28 },
  xAxis: { type: 'category', data: timeLabels.value, axisLabel: { rotate: xAxisLabelRotate.value } },
  yAxis: { type: 'value', name: 'ms' },
  series: [
    {
      name: 'Assemble',
      type: 'line',
      smooth: true,
      data: historyAsc.value.map((s) => s.lastAssembleMs),
      lineStyle: { width: 2, color: CHART.value.primary },
      itemStyle: { color: CHART.value.primary },
      symbol: 'circle',
      symbolSize: 6,
      z: 10,
    },
    {
      name: 'L2',
      type: 'bar',
      data: historyAsc.value.map((s) => s.lastL2Ms),
      itemStyle: { color: CHART.value.info },
    },
    {
      name: 'L3',
      type: 'bar',
      data: historyAsc.value.map((s) => s.lastL3Ms),
      itemStyle: { color: CHART.value.warning },
    },
    {
      name: 'L4',
      type: 'bar',
      data: historyAsc.value.map((s) => s.lastL4Ms),
      itemStyle: { color: CHART.value.success },
    },
  ],
}));

// 时序图3：tier 分布（堆叠面积图，Y 轴次数）
// M7: 使用半透明渐变填充替代纯色填充，提升暗色主题下的视觉层次感。
const tierOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  legend: { data: ['Low', 'Medium', 'High'] },
  grid: { left: 56, right: 20, top: 36, bottom: 28 },
  xAxis: { type: 'category', data: timeLabels.value, boundaryGap: false, axisLabel: { rotate: xAxisLabelRotate.value } },
  yAxis: { type: 'value', name: '次数' },
  series: [
    {
      name: 'Low',
      type: 'line',
      stack: 'tier',
      areaStyle: { color: isDark.value ? 'rgba(54,173,106,0.25)' : 'rgba(24,160,88,0.15)' },
      lineStyle: { color: CHART.value.success },
      itemStyle: { color: CHART.value.success },
      symbol: 'circle',
      symbolSize: 3,
      data: historyAsc.value.map((s) => s.tierLow),
    },
    {
      name: 'Medium',
      type: 'line',
      stack: 'tier',
      areaStyle: { color: isDark.value ? 'rgba(252,176,64,0.25)' : 'rgba(240,160,32,0.15)' },
      lineStyle: { color: CHART.value.warning, type: 'dashed' },
      itemStyle: { color: CHART.value.warning },
      symbol: 'diamond',
      symbolSize: 3,
      data: historyAsc.value.map((s) => s.tierMedium),
    },
    {
      name: 'High',
      type: 'line',
      stack: 'tier',
      areaStyle: { color: isDark.value ? 'rgba(222,81,105,0.25)' : 'rgba(208,48,80,0.15)' },
      lineStyle: { color: CHART.value.danger, type: 'dotted' },
      itemStyle: { color: CHART.value.danger },
      symbol: 'triangle',
      symbolSize: 3,
      data: historyAsc.value.map((s) => s.tierHigh),
    },
  ],
}));

// ===== Cascade top 10 Beta 分布柱状图 =====
const cascadeTopArms = computed(
  () => memory.value?.cascade?.topArms?.slice(0, 10) ?? [],
);
// R-2: cascade Tier 1 置信度（来自 memory.health.latest，仅内存态）
const cascadeTier1Confidence = computed<number | null>(() => {
  const v = memory.value?.health?.latest?.cascadeTier1Confidence;
  return typeof v === 'number' ? Math.round(v * 1000) / 1000 : null;
});
const cascadeJudgeSource = computed<'gm-pro' | 'local' | null>(
  () => memory.value?.health?.latest?.cascadeJudgeSource ?? null,
);

// v1.1-7: 降级链路状态 —— 来自 memory.health.latest 的 UX 指标 + 最近一次降级原因
const uxSnapshot = computed(() => memory.value?.health?.latest ?? null);
const lastDegradedReasons = computed<string[]>(() => {
  const r = uxSnapshot.value?.lastDegradedReasons;
  return Array.isArray(r) ? r : [];
});
const uxSummary = computed(() => {
  const s = uxSnapshot.value;
  if (!s) {
    return { degradationRate: 0, tokenSavedRatio: 0, experienceHitRate: 0, totalAssembles: 0, degradedCount: 0 };
  }
  // v2.4.0: 优先使用全局累计计数器（跨窗口持久化），fallback 到 per-window 值
  const hasGlobalUx = typeof s.globalTotalAssembleCount === 'number' && s.globalTotalAssembleCount > 0;
  const total = hasGlobalUx ? (s.globalTotalAssembleCount ?? 0) : (s.totalAssembleCount ?? 0);
  const degraded = hasGlobalUx ? (s.globalDegradedCount ?? 0) : (s.degradedCount ?? 0);
  const expQuery = hasGlobalUx ? (s.globalExperienceQueryCount ?? 0) : (s.experienceQueryCount ?? 0);
  const expHit = hasGlobalUx ? (s.globalExperienceHitCount ?? 0) : (s.experienceHitCount ?? 0);
  return {
    degradationRate: total > 0 ? degraded / total : 0,
    tokenSavedRatio: s.tokenSavedRatio ?? 0,
    experienceHitRate: expQuery > 0 ? expHit / expQuery : 0,
    totalAssembles: total,
    degradedCount: degraded,
  };
});
// 各检索层当前是否处于降级（基于 lastDegradedReasons 关键字匹配）
const layerStatus = computed(() => {
  const r = lastDegradedReasons.value;
  const has = (kw: string[]) => kw.some((k) => r.some((x) => x.toLowerCase().includes(k)));
  return {
    L1: has(['l1_', 'qmd']),
    L2: has(['l2_', 'circuit']),
    L3: has(['l3_', 'graph']),
    L4: has(['l4_', 'experience']),
    gmPro: has(['gm_pro', 'gmpro', 'cascade']),
  };
});
// 降级率 tag 颜色：>50% error, >10% warning, 否则 success
const degradationTagType = computed<'success' | 'warning' | 'error' | 'default'>(() => {
  const r = uxSummary.value.degradationRate;
  if (r > 0.5) return 'error';
  if (r > 0.1) return 'warning';
  if (uxSummary.value.totalAssembles > 0) return 'success';
  return 'default';
});
const betaOption = computed(() => {
  const arms = cascadeTopArms.value;
  return {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['alpha', 'beta'] },
    grid: { left: 48, right: 16, top: 30, bottom: 48 },
    xAxis: {
      type: 'category',
      data: arms.map((a) =>
        a.armKey.length > 12 ? a.armKey.slice(0, 10) + '…' : a.armKey,
      ),
      axisLabel: { rotate: 30, fontSize: 10 },
    },
    yAxis: { type: 'value' },
    series: [
      { name: 'alpha', type: 'bar', data: arms.map((a) => a.alpha), itemStyle: { color: CHART.value.primary } },
      { name: 'beta', type: 'bar', data: arms.map((a) => a.beta), itemStyle: { color: CHART.value.info } },
    ],
  };
});

// ===== 用户画像 top 标签 =====
const topTechStack = computed(() => {
  const ts = memory.value?.userProfile?.techStack ?? [];
  return [...ts].sort((a, b) => b.weight - a.weight).slice(0, 5);
});
const topScenario = computed(() => {
  const sc = memory.value?.userProfile?.scenario ?? [];
  return [...sc].sort((a, b) => b.weight - a.weight).slice(0, 5);
});
const userLanguage = computed(() => memory.value?.userProfile?.language ?? '—');

// ===== Agent 额外字段（排除 online/error） =====
const agentExtraFields = computed(() => {
  const a = agent.value;
  if (!a) return [];
  return Object.entries(a)
    .filter(([k]) => k !== 'online' && k !== 'error')
    .map(([k, v]) => ({
      key: k,
      value: typeof v === 'object' && v !== null ? JSON.stringify(v) : String(v),
    }));
});

// 响应式列数（naive-ui 描述符字符串 + responsive="screen"，断点 xs/s/m/l/xl/xxl）
// KPI 卡片：小屏 2 列，宽屏（l≥1280）4 列
const kpiCols = '2 s:2 m:2 l:4';
// 时序图区下半部分：小屏 1 列，中屏（m≥1024）2 列
const chartCols = '1 s:1 m:2';
// 状态面板：小屏 1 列，中屏 2 列，宽屏（l≥1280）3 列
const panelCols = '1 s:1 m:2 l:3';

// H2 修复：聚合错误摘要（供状态面板 Tab 顶部错误条使用）
const failedPanelSummary = computed(() => {
  const failed: string[] = [];
  if (latestIsError.value) failed.push('健康指标 / 熔断 / memory');
  if (graphHealthIsError.value) failed.push('图谱健康');
  if (agentIsError.value) failed.push('Agent 状态');
  return failed.length ? failed.join('、') + ' 加载失败' : '';
});

// S4-2: Tab 分组（KPI / 时序 / 状态面板），降低单屏信息密度
// 默认激活 KPI tab；display-directive="show" 保持所有面板在 DOM（测试可访问文本）
const activeTab = ref<'overview' | 'panels' | 'moa'>('overview');

// P3-14: NTabs 切换路由同步（读取 URL query ?tab=）
const router = useRouter();
const route = useRoute();

const tabFromQuery = (route.query.tab as string) ?? '';
if (tabFromQuery === 'overview' || tabFromQuery === 'panels' || tabFromQuery === 'moa') {
  activeTab.value = tabFromQuery;
}

watch(activeTab, (tab) => {
  router.replace({ query: { ...route.query, tab } }).catch(() => {});
});

// ===== MoA 辅助函数 =====
function formatMs(ms: number): string {
  if (ms <= 0) return '--';
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60_000).toFixed(1)}min`;
}

function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function formatTimeHMS(ts: number): string {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
}

const moaSuccessRate = computed(() => {
  if (!moaPerf.value || moaPerf.value.totalRuns === 0) return 0;
  return (moaPerf.value.successRuns / moaPerf.value.totalRuns) * 100;
});

const moaSuccessRateType = computed(() => {
  const r = moaSuccessRate.value;
  return r >= 90 ? 'success' : r >= 70 ? 'warning' : 'error';
});

const moaErrorItems = computed(() => {
  if (!moaPerf.value?.errorBreakdown) return [];
  return Object.entries(moaPerf.value.errorBreakdown)
    .sort((a, b) => b[1] - a[1]);
});

// ===== MoA 复杂度趋势图（实时 / 按小时 / 按天 多维度切换） =====
const moaComplexityTrendOption = computed(() => {
  const agg = complexityAggregation.value;
  const rangeMs = timeRangeToMs(complexityTimeRange.value);
  const now = Date.now();

  // ── 实时模式：每轮对话的数据点 ──
  if (agg === 'raw') {
    const allHistory = moaPerf.value?.allComplexityHistory;
    const moaHistory = moaPerf.value?.complexityHistory;
    if (!allHistory || allHistory.length === 0) return {};

    const sorted = [...allHistory]
      .sort((a, b) => a.timestamp - b.timestamp)
      .filter((r) => now - r.timestamp <= rangeMs)
      .slice(-30);

    if (sorted.length === 0) return {};

    const xLabels = sorted.map((r) => {
      const d = new Date(r.timestamp);
      return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    });

    const allSeries = {
      name: '全量复杂度',
      type: 'line',
      data: sorted.map((r, i) => [i, r.score]),
      smooth: true,
      lineStyle: { color: CHART.value.primary, width: 2 },
      itemStyle: { color: CHART.value.primary },
      symbol: 'circle',
      symbolSize: 6,
      markLine: {
        silent: true,
        symbol: 'none',
        lineStyle: { color: CHART.value.warning, type: 'dashed' },
        data: [{ yAxis: 0.6, label: { formatter: '阈值 0.6' } }],
      },
    };

    const moaTimestamps = new Set((moaHistory ?? []).map((r) => r.timestamp));
    // PERF-6: 使用 Map 预建索引，避免 sorted.indexOf(r) 的 O(n²) 查找。
    // 修复前：moaPoints 中 .map((r) => [sorted.indexOf(r), r.score]) 每次遍历 sorted 查找。
    const sortedIndexMap = new Map(sorted.map((r, i) => [r.timestamp, i]));
    const moaPoints = sorted
      .filter((r) => moaTimestamps.has(r.timestamp))
      .map((r) => [sortedIndexMap.get(r.timestamp) ?? 0, r.score]);

    const moaSeries = moaPoints.length > 0 ? {
      name: 'MoA 触发',
      type: 'scatter',
      data: moaPoints,
      symbolSize: 10,
      itemStyle: { color: CHART.value.danger },
      symbol: 'diamond',
      z: 10,
    } : undefined;

    const series = moaSeries ? [allSeries, moaSeries] : [allSeries];

    return {
      title: undefined,
      tooltip: {
        trigger: 'axis',
        formatter: (params: any) => {
          const items = Array.isArray(params) ? params : [params];
          const idx = items[0]?.data?.[0];
          const label = idx !== undefined && idx < xLabels.length ? xLabels[idx] : '';
          let html = `${label}<br/>`;
          for (const p of items) {
            const val = p.data?.[1];
            html += `${p.marker}${p.seriesName}: ${val !== null && val !== undefined ? (val as number).toFixed(3) : '—'}<br/>`;
          }
          return html;
        },
      },
      legend: { data: moaSeries ? ['全量复杂度', 'MoA 触发'] : ['全量复杂度'], bottom: 0 },
      xAxis: {
        type: 'category',
        data: xLabels,
        axisLabel: { fontSize: 10, rotate: 45 },
        name: '时间',
        nameLocation: 'middle',
        nameGap: 30,
      },
      yAxis: { type: 'value', name: '评分', min: 0, max: 1, axisLabel: { formatter: (v: number) => v.toFixed(1) } },
      series,
      grid: { left: 50, right: 30, bottom: 55, top: 45 },
    };
  }

  // ── 按小时模式 ──
  if (agg === 'hourly') {
    const hourly = moaPerf.value?.complexityHourlyBuckets;
    if (!hourly || hourly.length === 0) return {};

    // 按时间范围过滤：hourly 是最近 24 小时的桶，按 rangeMs 截取
    const maxHours = Math.ceil(rangeMs / 3600_000);
    const filtered = hourly.slice(-Math.min(maxHours, hourly.length));
    if (filtered.length === 0) return {};

    const allSeries = {
      name: '全量 (小时均)',
      type: 'line',
      data: filtered.map((b) => [b.hour, b.avg]),
      smooth: true,
      lineStyle: { color: CHART.value.primary, width: 2 },
      itemStyle: { color: CHART.value.primary },
      symbol: 'circle',
      symbolSize: 6,
      areaStyle: { color: 'rgba(32,128,240,0.08)' },
      markLine: {
        silent: true,
        symbol: 'none',
        lineStyle: { color: CHART.value.warning, type: 'dashed' },
        data: [{ yAxis: 0.6, label: { formatter: '阈值 0.6' } }],
      },
    };

    // MoA 触发按小时聚合
    const moaHistory = moaPerf.value?.complexityHistory;
    const moaByHour: Map<string, number[]> = new Map();
    if (moaHistory) {
      for (const h of moaHistory) {
        if (now - h.timestamp > rangeMs) continue;
        const d = new Date(h.timestamp);
        const key = `${String(d.getHours()).padStart(2, '0')}:00`;
        if (!moaByHour.has(key)) moaByHour.set(key, []);
        moaByHour.get(key)!.push(h.score);
      }
    }
    const moaData = filtered.map((b) => {
      const scores = moaByHour.get(b.hour) ?? [];
      return [b.hour, scores.length > 0 ? Math.round(scores.reduce((a, c) => a + c, 0) / scores.length * 1000) / 1000 : null];
    });
    const hasMoaData = moaData.some((d) => d[1] !== null);

    const moaSeries = hasMoaData ? {
      name: 'MoA 触发 (小时均)',
      type: 'line',
      data: moaData,
      smooth: true,
      lineStyle: { color: CHART.value.danger, width: 2 },
      itemStyle: { color: CHART.value.danger },
      symbol: 'diamond',
      symbolSize: 8,
      connectNulls: false,
    } : undefined;

    const series = moaSeries ? [allSeries, moaSeries] : [allSeries];

    return {
      title: undefined,
      tooltip: { trigger: 'axis', formatter: (params: any) => {
        const items = Array.isArray(params) ? params : [params];
        let html = `${items[0].axisValue}<br/>`;
        for (const p of items) {
          const val = p.data?.[1];
          html += `${p.marker}${p.seriesName}: ${val !== null && val !== undefined ? (val as number).toFixed(3) : '—'}<br/>`;
        }
        return html;
      }},
      legend: { data: moaSeries ? ['全量 (小时均)', 'MoA 触发 (小时均)'] : ['全量 (小时均)'], bottom: 0 },
      xAxis: { type: 'category', data: filtered.map((b) => b.hour), axisLabel: { fontSize: 10 } },
      yAxis: { type: 'value', name: '评分', min: 0, max: 1, axisLabel: { formatter: (v: number) => v.toFixed(1) } },
      series,
      grid: { left: 50, right: 30, bottom: 45, top: 45 },
    };
  }

  // ── 按天模式 ──
  const daily = moaPerf.value?.complexityDailyBuckets;
  if (!daily || daily.length === 0) return {};

  const maxDays = Math.ceil(rangeMs / 86_400_000);
  const filtered = daily.slice(-Math.min(maxDays, daily.length));
  if (filtered.length === 0) return {};

  const allSeries = {
    name: '全量 (日均)',
    type: 'line',
    data: filtered.map((b) => [b.date, b.avg]),
    smooth: true,
    lineStyle: { color: CHART.value.primary, width: 2 },
    itemStyle: { color: CHART.value.primary },
    symbol: 'circle',
    symbolSize: 8,
    areaStyle: { color: 'rgba(32,128,240,0.08)' },
    markLine: {
      silent: true,
      symbol: 'none',
      lineStyle: { color: CHART.value.warning, type: 'dashed' },
      data: [{ yAxis: 0.6, label: { formatter: '阈值 0.6' } }],
    },
  };

  // MoA 触发按天聚合
  const moaHistory = moaPerf.value?.complexityHistory;
  const moaByDay: Map<string, number[]> = new Map();
  if (moaHistory) {
    for (const h of moaHistory) {
      if (now - h.timestamp > rangeMs) continue;
      const d = new Date(h.timestamp);
      const key = `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      if (!moaByDay.has(key)) moaByDay.set(key, []);
      moaByDay.get(key)!.push(h.score);
    }
  }
  const moaData = filtered.map((b) => {
    const scores = moaByDay.get(b.date) ?? [];
    return [b.date, scores.length > 0 ? Math.round(scores.reduce((a, c) => a + c, 0) / scores.length * 1000) / 1000 : null];
  });
  const hasMoaData = moaData.some((d) => d[1] !== null);

  const moaSeries = hasMoaData ? {
    name: 'MoA 触发 (日均)',
    type: 'line',
    data: moaData,
    smooth: true,
    lineStyle: { color: CHART.value.danger, width: 2 },
    itemStyle: { color: CHART.value.danger },
    symbol: 'diamond',
    symbolSize: 8,
    connectNulls: false,
  } : undefined;

  const series = moaSeries ? [allSeries, moaSeries] : [allSeries];

  return {
    title: undefined,
    tooltip: { trigger: 'axis', formatter: (params: any) => {
      const items = Array.isArray(params) ? params : [params];
      let html = `${items[0].axisValue}<br/>`;
      for (const p of items) {
        const val = p.data?.[1];
        html += `${p.marker}${p.seriesName}: ${val !== null && val !== undefined ? (val as number).toFixed(3) : '—'}<br/>`;
      }
      return html;
    }},
    legend: { data: moaSeries ? ['全量 (日均)', 'MoA 触发 (日均)'] : ['全量 (日均)'], bottom: 0 },
    xAxis: { type: 'category', data: filtered.map((b) => b.date), axisLabel: { fontSize: 10 } },
    yAxis: { type: 'value', name: '评分', min: 0, max: 1, axisLabel: { formatter: (v: number) => v.toFixed(1) } },
    series,
    grid: { left: 50, right: 30, bottom: 45, top: 45 },
  };
});

// ===== MoA 复杂度分布图（全量 vs MoA 触发 分组对比） =====
const moaComplexityDistOption = computed(() => {
  const moaDist = moaPerf.value?.complexityDistribution;
  const allDist = moaPerf.value?.allComplexityDistribution;
  if (!allDist) return {};

  const allTotal = allDist.low + allDist.medium + allDist.high;
  const moaTotal = moaDist ? moaDist.low + moaDist.medium + moaDist.high : 0;

  return {
    title: undefined,
    tooltip: { trigger: 'axis', formatter: (params: any) => {
      let html = '';
      for (const p of params) {
        html += `${p.marker}${p.seriesName}: ${p.value}<br/>`;
      }
      html += `全量总计: ${allTotal}<br/>`;
      html += `MoA 触发: ${moaTotal} (${allTotal > 0 ? Math.round(moaTotal / allTotal * 100) : 0}%)`;
      return html;
    }},
    legend: { data: ['全量', 'MoA 触发'], bottom: 0 },
    xAxis: { type: 'category', data: ['低 (0-0.4)', '中 (0.4-0.7)', '高 (0.7-1.0)'], axisLabel: { fontSize: 11 } },
    yAxis: { type: 'value', name: '次数', minInterval: 1 },
    series: [
      {
        name: '全量',
        type: 'bar',
        data: [allDist.low, allDist.medium, allDist.high],
        itemStyle: { color: CHART.value.primary },
        label: { show: true, position: 'top', formatter: '{c}' },
      },
      {
        name: 'MoA 触发',
        type: 'bar',
        data: moaDist ? [moaDist.low, moaDist.medium, moaDist.high] : [0, 0, 0],
        itemStyle: { color: CHART.value.danger },
        label: { show: true, position: 'top', formatter: '{c}' },
      },
    ],
    grid: { left: 50, right: 30, bottom: 60, top: 45 },
  };
});

// ===== MoA 最近运行表格列 =====
const moaRunsColumns = computed(() => [
  { title: '时间', key: 'timestamp', width: 80, render: (row: any) => h('span', { class: 'mono' }, formatTimeHMS(row.timestamp)) },
  { title: '查询', key: 'queryPreview', ellipsis: { tooltip: true }, render: (row: any) => row.queryPreview.slice(0, 50) },
  { title: '复杂度', key: 'complexityScore', width: 80, render: (row: any) => row.complexityScore !== undefined ? row.complexityScore.toFixed(3) : '—' },
  { title: '模式', key: 'mode', width: 80, render: (row: any) => h(NTag, { size: 'tiny', type: row.mode === 'parallel' ? 'info' : 'default' }, { default: () => row.mode }) },
  { title: '状态', key: 'success', width: 70, render: (row: any) => h(NTag, { size: 'tiny', type: row.success ? 'success' : 'error' }, { default: () => row.success ? '成功' : '失败' }) },
  { title: '总耗时', key: 'totalMs', width: 80, render: (row: any) => h('span', { class: 'mono' }, formatMs(row.totalMs)) },
  { title: '参考', key: 'refCount', width: 120, render: (row: any) => h('span', { class: 'mono' }, `${row.validRefCount}/${row.refCount} (${formatMs(row.refMs)})`) },
  { title: '聚合', key: 'aggMs', width: 100, render: (row: any) => h('span', { class: 'mono' }, formatMs(row.aggMs)) },
  { title: 'Tokens', key: 'totalTokens', width: 80, render: (row: any) => h('span', { class: 'mono' }, formatTokens(row.totalTokens)) },
]);
const moaLatencyPhaseOption = computed(() => {
  const runs = moaPerf.value?.recentRuns;
  if (!runs || runs.length === 0) return {};
  const data = [...runs].slice(0, 10).reverse();
  return {
    title: undefined,
    tooltip: { trigger: 'axis', formatter: (params: any) => { let h = params[0].name + '<br/>'; for (const p of params) h += `${p.marker}${p.seriesName}: ${Number(p.value).toFixed(0)}ms<br/>`; return h; } },
    legend: { data: ['参考模型', '聚合模型'], bottom: 0 },
    xAxis: { type: 'category', data: data.map((r) => r.queryPreview.slice(0, 16) + (r.queryPreview.length > 16 ? '...' : '')), axisLabel: { fontSize: 10, rotate: 30 } },
    yAxis: { type: 'value', name: '耗时 (ms)' },
    series: [
      { name: '参考模型', type: 'bar', stack: 'total', data: data.map((r) => r.refMs), itemStyle: { color: CHART.value.primary } },
      { name: '聚合模型', type: 'bar', stack: 'total', data: data.map((r) => r.aggMs), itemStyle: { color: CHART.value.success } },
    ],
    grid: { left: 60, right: 30, bottom: 60, top: 45 },
  };
});
</script>

<template>
  <div class="monitor-view">
    <!-- 标题行 -->
    <div class="monitor-header">
      <h2 style="margin: 0">性能监控</h2>
      <div class="header-right">
        <!-- UX-2: 全局刷新状态指示器 -->
        <NTag :type="refreshStatus.type" size="small" :bordered="false">
          {{ refreshStatus.label }}
        </NTag>
        <span class="last-updated">最近更新: {{ lastUpdated }}</span>
      </div>
    </div>

    <NTabs
      v-model:value="activeTab"
      type="line"
      animated
      size="medium"
      style="margin-top: 12px"
      aria-label="监控视图分组"
    >
      <!-- ===== Tab 1: 总览（KPI + 时序图） ===== -->
      <NTabPane
        name="overview"
        tab="📊 总览"
        display-directive="show"
      >
        <NGrid :cols="kpiCols" :x-gap="12" :y-gap="12" responsive="screen">
          <NGi>
            <KpiCard
              label="待处理消息"
              :value="kpiPending"
              :threshold="100"
              :trend="kpiTrend.pending"
              :loading="latestLoading"
              reverse-indicator
            />
          </NGi>
          <NGi>
            <KpiCard
              label="Token 占用比"
              :value="kpiTokenRatio"
              unit="%"
              :threshold="80"
              :trend="kpiTrend.tokenRatio"
              :loading="latestLoading"
              reverse-indicator
            />
          </NGi>
          <NGi>
            <KpiCard
              label="检索延迟 Assemble"
              :value="kpiAssembleMs"
              unit="ms"
              :threshold="2000"
              :trend="kpiTrend.assembleMs"
              :loading="latestLoading"
              reverse-indicator
            />
          </NGi>
          <NGi>
            <KpiCard
              label="熔断失败总数"
              :value="kpiCbFailures"
              :threshold="0"
              :trend="kpiTrend.cbFailures"
              :loading="latestLoading"
              reverse-indicator
            />
          </NGi>
        </NGrid>

        <!-- P1-6: 当前压力 Tier 徽章（紧邻 KPI 区域） -->
        <div class="tier-badge-bar">
          <span class="tier-badge-label">当前压力 Tier：</span>
          <NTag
            v-if="currentTier"
            :type="currentTierTagType"
            size="medium"
            round
          >
            {{ currentTierLabel }}
          </NTag>
          <NTag v-else type="default" size="medium" round>—</NTag>
          <span v-if="db" class="tier-badge-detail muted mono">
            Low: {{ db.tierLow }} · Medium: {{ db.tierMedium }} · High: {{ db.tierHigh }}
          </span>
        </div>

        <NAlert
          v-if="latestIsError"
          type="error"
          :show-icon="true"
          title="健康指标加载失败"
          style="margin-top: 12px"
        >
          后端 /api/health/latest 不可达或返回错误。请检查插件 snapshot 服务（:7423）是否运行。
        </NAlert>
        <NAlert
          v-else-if="agentIsError"
          type="error"
          :show-icon="true"
          title="Agent 状态加载失败"
          style="margin-top: 12px"
        >
          后端 /api/agent/status 不可达。
        </NAlert>
        <NAlert
          v-else-if="graphHealthIsError"
          type="error"
          :show-icon="true"
          title="图谱健康加载失败"
          style="margin-top: 12px"
        >
          后端 /api/graph/health 不可达。
        </NAlert>
        <NAlert
          v-else-if="historyIsError"
          type="error"
          :show-icon="true"
          title="时序图历史加载失败"
          style="margin-top: 12px"
        >
          后端 /api/health/history 不可达。
        </NAlert>
        <NAlert
          v-if="latestLoading && !latestData"
          type="info"
          :show-icon="true"
          title="正在加载最新健康指标…"
          style="margin-top: 12px"
        />

        <NDivider style="margin: 16px 0" />

        <!-- 时间范围 + 统计粒度 -->
        <div class="granularity-bar">
          <span class="granularity-label">时间范围：</span>
          <NSelect
            v-model:value="timeRange"
            :options="timeRangeOptions"
            size="small"
            style="width: 140px"
            aria-label="选择时间范围"
          />
          <span class="granularity-label" style="margin-left: 12px">统计粒度：</span>
          <NSelect
            v-model:value="bucketSize"
            :options="bucketSizeOptions"
            size="small"
            style="width: 120px"
            aria-label="选择统计粒度"
          />
          <span class="granularity-hint">
            {{ rangeBucketHint }}
          </span>
        </div>
        <NSpace vertical :size="12">
          <NCard title="压力信号（待处理消息 / 摘要片段 / Token 占用比）" size="small">
            <EChart v-if="historyAsc.length" :option="pressureOption" height="280px" aria-label="压力信号时序图：待处理消息、摘要片段和 Token 占用比随时间变化" />
            <div v-else-if="historyLoading" class="chart-loading">
              <NSpin size="small" />
            </div>
            <NEmpty
              v-else
              :description="historyIsError ? '加载失败，见上方错误提示' : '暂无压力信号数据'"
              style="padding: 24px 0"
            >
              <template v-if="!historyIsError" #extra>
                <span class="muted" style="font-size: var(--fs-caption)">启动后端 heartbeat 服务后，数据将自动出现。</span>
              </template>
            </NEmpty>
          </NCard>
          <NGrid :cols="chartCols" :x-gap="12" :y-gap="12" responsive="screen">
            <NGi>
              <NCard title="检索延迟（Assemble 折线 + 各检索层独立柱状图）" size="small">
                <EChart v-if="historyAsc.length" :option="latencyOption" height="280px" aria-label="检索延迟图：Assemble 总耗时折线和 L2/L3/L4 各层耗时柱状图" />
                <div v-else-if="historyLoading" class="chart-loading">
                  <NSpin size="small" />
                </div>
                <NEmpty
                  v-else
                  :description="historyIsError ? '加载失败，见上方错误提示' : '暂无检索延迟数据'"
                  style="padding: 24px 0"
                />
              </NCard>
            </NGi>
            <NGi>
              <NCard title="压力等级分布（Low / Medium / High 堆叠面积）" size="small">
                <EChart v-if="historyAsc.length" :option="tierOption" height="280px" aria-label="Tier 分布堆叠面积图：Low、Medium、High 三级压力分布随时间变化" />
                <div v-else-if="historyLoading" class="chart-loading">
                  <NSpin size="small" />
                </div>
                <NEmpty
                  v-else
                  :description="historyIsError ? '加载失败，见上方错误提示' : '暂无压力等级分布数据'"
                  style="padding: 24px 0"
                />
              </NCard>
            </NGi>
          </NGrid>
        </NSpace>

        <!-- P1-2 / P1-6: 熔断器状态 + 最近 10 次 tier 趋势 -->
        <NGrid :cols="chartCols" :x-gap="12" :y-gap="12" responsive="screen" style="margin-top: 12px">
          <!-- P1-2: 熔断器状态卡片（含成功率 + 开合次数 + 重置按钮） -->
          <NGi>
            <NCard title="熔断器状态" size="small">
              <template v-if="cbSubsystemStats.length">
                <NSpace vertical :size="8">
                  <div
                    v-for="item in cbSubsystemStats"
                    :key="item.key"
                    class="cb-row"
                  >
                    <span class="cb-label">{{ item.label }}</span>
                    <NTag size="small" :type="item.tagType">
                      {{ item.available ? '可用' : item.failures > 0 ? '熔断' : '未知' }}
                    </NTag>
                    <span class="cb-failures muted mono">失败 {{ item.failures }} 次</span>
                    <span class="cb-stat muted mono">
                      成功率 {{ item.successRate }}% · 开合 {{ item.openCloseCount }} 次
                    </span>
                    <!-- UX-7: 熔断器重置按钮添加二次确认 -->
                    <NPopconfirm
                      @positive-click="handleResetBreaker(item.key)"
                    >
                      <template #trigger>
                        <NButton
                          size="tiny"
                          :type="item.available ? 'default' : 'warning'"
                          :loading="resettingBreaker === item.key"
                          :disabled="resettingBreaker !== null && resettingBreaker !== item.key"
                        >
                          重置
                        </NButton>
                      </template>
                      确定要重置 {{ item.label }} 熔断器吗？这将清零失败计数并关闭熔断状态。
                    </NPopconfirm>
                  </div>
                </NSpace>
              </template>
              <NEmpty v-else description="无历史数据" style="padding: 12px 0" />
            </NCard>
          </NGi>

          <!-- P1-6: 最近 10 次 tier 分布趋势 -->
          <NGi>
            <NCard title="最近 10 次 tier 分布趋势" size="small">
              <template v-if="recentTierTrend.length">
                <!-- 当前 tier 分布占比（NProgress 三条） -->
                <div v-if="db" class="tier-current-dist">
                  <div class="tier-dist-row">
                    <span class="tier-dist-label">Low</span>
                    <NProgress
                      type="line"
                      :percentage="currentTierDistribution.lowPct"
                      :color="CHART.success"
                      :show-indicator="false"
                      :height="8"
                      style="flex: 1"
                    />
                    <span class="tier-dist-value mono">
                      {{ currentTierDistribution.low }} ({{ currentTierDistribution.lowPct.toFixed(0) }}%)
                    </span>
                  </div>
                  <div class="tier-dist-row">
                    <span class="tier-dist-label">Medium</span>
                    <NProgress
                      type="line"
                      :percentage="currentTierDistribution.mediumPct"
                      :color="CHART.warning"
                      :show-indicator="false"
                      :height="8"
                      style="flex: 1"
                    />
                    <span class="tier-dist-value mono">
                      {{ currentTierDistribution.medium }} ({{ currentTierDistribution.mediumPct.toFixed(0) }}%)
                    </span>
                  </div>
                  <div class="tier-dist-row">
                    <span class="tier-dist-label">High</span>
                    <NProgress
                      type="line"
                      :percentage="currentTierDistribution.highPct"
                      :color="CHART.danger"
                      :show-indicator="false"
                      :height="8"
                      style="flex: 1"
                    />
                    <span class="tier-dist-value mono">
                      {{ currentTierDistribution.high }} ({{ currentTierDistribution.highPct.toFixed(0) }}%)
                    </span>
                  </div>
                </div>
                <NDivider style="margin: 8px 0" />
                <!-- 最近 10 次轨迹（水平条形图） -->
                <div class="tier-trend-list">
                  <div
                    v-for="point in recentTierTrend"
                    :key="point.timestamp"
                    class="tier-trend-row"
                  >
                    <span class="tier-trend-time mono">{{ formatTime(point.timestamp) }}</span>
                    <div class="tier-trend-bar">
                      <div
                        class="tier-trend-seg tier-low"
                        :style="{ width: point.lowPct + '%' }"
                      />
                      <div
                        class="tier-trend-seg tier-medium"
                        :style="{ width: point.mediumPct + '%' }"
                      />
                      <div
                        class="tier-trend-seg tier-high"
                        :style="{ width: point.highPct + '%' }"
                      />
                    </div>
                    <NTag
                      size="tiny"
                      :type="point.dominant === 'high' ? 'error' : point.dominant === 'medium' ? 'warning' : point.dominant === 'low' ? 'success' : 'default'"
                    >
                      {{ point.dominant ?? '—' }}
                    </NTag>
                    <span class="tier-trend-total mono muted">{{ point.total }}</span>
                  </div>
                </div>
              </template>
              <NEmpty v-else description="无历史数据" style="padding: 12px 0" />
            </NCard>
          </NGi>
        </NGrid>

        <div style="margin-top: 4px; font-size: var(--fs-caption); color: var(--color-text-muted);">
          最近更新: {{ lastUpdated || '—' }}
        </div>
      </NTabPane>

      

      
      <NTabPane
        name="panels"
        tab="🔧 服务状态"
        display-directive="show"
      >
        <!-- 错误态穿透 -->
        <NAlert
          v-if="latestIsError || graphHealthIsError || agentIsError"
          type="error"
          :show-icon="true"
          title="部分状态面板加载失败"
          style="margin-bottom: 12px"
        >
          {{ failedPanelSummary }}。服务恢复后将自动重试。
        </NAlert>

        <!-- ═══════════════ 核心服务 ═══════════════ -->
        <NDivider title-placement="left" style="margin: 4px 0 12px">核心服务</NDivider>

        <!-- gm-pro 服务状态（全宽表格） -->
        <NCard title="gm-pro 服务状态" size="small" style="margin-bottom: 12px">
          <template v-if="gmProServices">
            <div class="svc-header-row">
              <NTag type="info" size="small">v{{ gmProServices.version }}</NTag>
              <span class="muted" style="font-size:var(--fs-caption)">
                {{ gmProServices.timestamp ? (gmProServices.timestamp as string).slice(0, 19).replace('T', ' ') : '—' }}
              </span>
            </div>
            <!-- 服务列表表格 -->
            <table class="svc-table" v-if="(gmProServices.services ?? []).length">
              <thead>
                <tr>
                  <th>服务</th>
                  <th>状态</th>
                  <th>详情</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="svc in (gmProServices.services ?? [])" :key="svc.name">
                  <td class="mono svc-name">{{ svc.name }}</td>
                  <td>
                    <NTag
                      size="tiny"
                      :type="svc.status === 'connected' || svc.status === 'running' || svc.status === 'ok' || svc.status === 'configured' || svc.status === 'initialized' ? 'success' : svc.status === 'disconnected' || svc.status === 'not-initialized' || svc.status === 'error' ? 'error' : 'warning'"
                    >
                      {{ svc.status }}
                    </NTag>
                  </td>
                  <td class="svc-detail">
                    <template v-if="svc.detail">
                      <span v-if="typeof svc.detail === 'object' && !Array.isArray(svc.detail)">
                        <span v-for="(v, k) in (svc.detail as Record<string, unknown>)" :key="k" class="svc-detail-kv">
                          <span class="muted">{{ k }}:</span> {{ typeof v === 'object' ? JSON.stringify(v).slice(0, 80) : String(v).slice(0, 80) }}
                        </span>
                      </span>
                      <span v-else class="muted">{{ String(svc.detail).slice(0, 120) }}</span>
                    </template>
                    <span v-else class="muted">—</span>
                  </td>
                </tr>
              </tbody>
            </table>
            <NEmpty v-else description="服务列表为空" style="padding:8px 0" />
          </template>
          <NEmpty v-else description="gm-pro 服务不可达" style="padding:12px 0">
            <template #extra>
              <span class="muted" style="font-size:var(--fs-caption)">请确认 graph-memory-pro HTTP 服务 (端口 7850) 已启动，且 openclaw.json 中 apiServer.authToken 配置正确。</span>
            </template>
          </NEmpty>
        </NCard>

        <NGrid :cols="panelCols" :x-gap="12" :y-gap="12" responsive="screen">
          <!-- Agent 状态 -->
          <NGi>
            <NCard title="Agent 状态" size="small">
              <div v-if="agentLoading && !agent" class="card-loading">
                <NSpin size="small" />
              </div>
              <template v-else-if="agent">
                <div class="profile-section">
                  <NTag :type="agent.online ? 'success' : 'error'" size="small">
                    {{ agent.online ? '在线' : '离线' }}
                  </NTag>
                </div>
                <NAlert
                  v-if="agent.error"
                  type="warning"
                  :show-icon="true"
                  style="margin: 8px 0"
                >
                  {{ agent.error }}
                </NAlert>
                <NDescriptions
                  v-if="agentExtraFields.length"
                  :column="1"
                  size="small"
                  label-placement="left"
                  bordered
                >
                  <NDescriptionsItem
                    v-for="f in agentExtraFields"
                    :key="f.key"
                    :label="f.key"
                  >
                    <span class="mono">{{ f.value }}</span>
                  </NDescriptionsItem>
                </NDescriptions>
              </template>
              <NEmpty v-else description="无 Agent 数据" style="padding: 12px 0" />
            </NCard>
          </NGi>

          <!-- 熔断状态 -->
          <NGi>
            <NCard title="熔断状态" size="small">
              <template v-if="db">
                <StatusIndicator label="LCM" :available="db.cbLcmAvailable" :failures="db.cbLcmFailures" />
                <StatusIndicator label="QMD" :available="db.cbQmdAvailable" :failures="db.cbQmdFailures" />
                <StatusIndicator label="Neo4j" :available="db.cbNeo4jAvailable" :failures="db.cbNeo4jFailures" />
              </template>
              <NEmpty v-else description="无历史数据" style="padding: 12px 0" />
            </NCard>
          </NGi>

          <!-- 降级链路状态 -->
          <NGi>
            <NCard title="降级链路" size="small">
              <template v-if="memory">
                <ul class="layer-grid" role="list">
                  <li class="layer-cell">
                    <span class="dot" :class="layerStatus.L1 ? 'dot-fail' : 'dot-ok'" aria-hidden="true">{{ layerStatus.L1 ? '✗' : '✓' }}</span>
                    <span class="layer-label">L1 QMD</span>
                  </li>
                  <li class="layer-cell">
                    <span class="dot" :class="layerStatus.L2 ? 'dot-fail' : 'dot-ok'" aria-hidden="true">{{ layerStatus.L2 ? '✗' : '✓' }}</span>
                    <span class="layer-label">L2 熔断</span>
                  </li>
                  <li class="layer-cell">
                    <span class="dot" :class="layerStatus.L3 ? 'dot-fail' : 'dot-ok'" aria-hidden="true">{{ layerStatus.L3 ? '✗' : '✓' }}</span>
                    <span class="layer-label">L3 图谱</span>
                  </li>
                  <li class="layer-cell">
                    <span class="dot" :class="layerStatus.L4 ? 'dot-fail' : 'dot-ok'" aria-hidden="true">{{ layerStatus.L4 ? '✗' : '✓' }}</span>
                    <span class="layer-label">L4 经验</span>
                  </li>
                  <li class="layer-cell">
                    <span class="dot" :class="layerStatus.gmPro ? 'dot-fail' : 'dot-ok'" aria-hidden="true">{{ layerStatus.gmPro ? '✗' : '✓' }}</span>
                    <span class="layer-label">gm-pro</span>
                  </li>
                </ul>
                <NDescriptions :column="1" size="small" label-placement="left" bordered style="margin-top: 8px">
                  <NDescriptionsItem label="降级率">
                    <NTag :type="degradationTagType" size="small">{{ (uxSummary.degradationRate * 100).toFixed(1) }}%</NTag>
                    <span class="muted mono" style="margin-left:6px">{{ uxSummary.degradedCount }}/{{ uxSummary.totalAssembles }}</span>
                  </NDescriptionsItem>
                  <NDescriptionsItem label="Token 节省率">
                    <span class="mono">{{ (uxSummary.tokenSavedRatio * 100).toFixed(1) }}%</span>
                  </NDescriptionsItem>
                  <NDescriptionsItem label="经验命中率">
                    <span class="mono">{{ (uxSummary.experienceHitRate * 100).toFixed(1) }}%</span>
                  </NDescriptionsItem>
                </NDescriptions>
                <div v-if="lastDegradedReasons.length" class="profile-section" style="margin-top:8px">
                  <div class="profile-label">最近降级原因</div>
                  <NSpace :size="4">
                    <NTag v-for="r in lastDegradedReasons" :key="r" size="small" type="warning">{{ r }}</NTag>
                  </NSpace>
                </div>
              </template>
              <NEmpty v-else description="插件未响应" style="padding: 12px 0" />
            </NCard>
          </NGi>
        </NGrid>

        <!-- ═══════════════ 图谱健康 ═══════════════ -->
        <NDivider title-placement="left" style="margin: 16px 0 12px">图谱健康</NDivider>

        <NGrid :cols="panelCols" :x-gap="12" :y-gap="12" responsive="screen">
          <!-- 图谱健康 + 社区（Tab 合并） -->
          <NGi>
            <NCard title="图谱健康" size="small">
              <div v-if="graphHealthLoading && !graphHealth" class="card-loading"><NSpin size="small" /></div>
              <NEmpty v-else-if="!graphHealth" description="无图谱健康数据" style="padding:12px 0" />

              <template v-else>
                <div class="profile-section" style="margin-bottom:8px">
                  <NTag :type="graphHealthTagType" size="small">{{ graphHealth.status }}</NTag>
                  <NTag :type="graphHealthSourceTagType" size="small" style="margin-left:6px">source: {{ graphHealth.source }}</NTag>
                </div>
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem label="nodeCount">{{ graphHealth.nodeCount ?? '—' }}</NDescriptionsItem>
                  <NDescriptionsItem label="relationshipCount">{{ graphHealth.relationshipCount ?? '—' }}</NDescriptionsItem>
                  <NDescriptionsItem label="graphAdapter">
                    <StatusIndicator label="connected" mode="connection" :available="!!graphHealth.graphAdapterConnected" :failures="graphHealth.circuitBreakerFailures ?? 0" />
                  </NDescriptionsItem>
                  <NDescriptionsItem v-if="graphHealth.circuitBreakerOpen !== undefined" label="熔断器">
                    <NTag :type="graphHealth.circuitBreakerOpen ? 'error' : 'success'" size="small">{{ graphHealth.circuitBreakerOpen ? 'OPEN' : 'CLOSED' }}</NTag>
                    <span class="mono" style="margin-left:6px">failures: {{ graphHealth.circuitBreakerFailures ?? 0 }}</span>
                  </NDescriptionsItem>
                </NDescriptions>
                <div v-if="graphHealth.error" class="muted mono" style="margin-top:6px">{{ graphHealth.error }}</div>
              </template>

              <!-- gm-pro 健康概览 -->
              <NDivider v-if="gmProHealth" style="margin:8px 0" />
              <template v-if="gmProHealth">
                <div class="profile-section" style="margin-bottom:4px">
                  <NTag type="success" size="small">gm-pro 概览</NTag>
                </div>
                <NGrid :cols="'2 s:2 m:3'" :x-gap="8" :y-gap="4" responsive="screen">
                  <NGi><div class="health-stat"><span class="health-stat-label">活跃节点</span><span class="health-stat-value">{{ gmProHealth.nodes?.active ?? '—' }} / {{ gmProHealth.nodes?.total ?? '—' }}</span></div></NGi>
                  <NGi><div class="health-stat"><span class="health-stat-label">孤立节点</span><span class="health-stat-value" :class="{ 'text-warning': (gmProHealth.isolatedNodes ?? 0) > 0 }">{{ gmProHealth.isolatedNodes ?? '—' }}</span></div></NGi>
                  <NGi><div class="health-stat"><span class="health-stat-label">高过时</span><span class="health-stat-value" :class="{ 'text-danger': (gmProHealth.highStaleNodes ?? 0) > 0 }">{{ gmProHealth.highStaleNodes ?? '—' }}</span></div></NGi>
                  <NGi><div class="health-stat"><span class="health-stat-label">社区数</span><span class="health-stat-value">{{ gmProHealth.communities ?? '—' }}</span></div></NGi>
                  <NGi><div class="health-stat"><span class="health-stat-label">平均 PR</span><span class="health-stat-value mono">{{ gmProHealth.avgPageRank?.toFixed(4) ?? '—' }}</span></div></NGi>
                  <NGi v-if="gmProHealth.anomalies?.length"><div class="health-stat"><span class="health-stat-label">异常</span><span class="health-stat-value text-warning">{{ gmProHealth.anomalies.length }} 项</span></div></NGi>
                </NGrid>
                <div v-if="gmProHealth.anomalies?.length" style="margin-top:6px">
                  <NSpace :size="4"><NTag v-for="a in gmProHealth.anomalies" :key="a" size="small" type="warning">{{ a }}</NTag></NSpace>
                </div>
              </template>

              <!-- gm-pro 熔断器 -->
              <template v-if="gmProHealth?.circuitBreakers">
                <NDivider style="margin:8px 0">熔断器</NDivider>
                <div v-for="(cb, name) in gmProHealth.circuitBreakers" :key="name" style="display:flex;align-items:center;gap:8px;padding:2px 0">
                  <span class="mono" style="font-size:var(--fs-caption);min-width:56px">{{ name }}</span>
                  <NTag :type="(cb as any).open ? 'error' : 'success'" size="tiny">{{ (cb as any).open ? 'OPEN' : 'CLOSED' }}</NTag>
                  <span class="muted" style="font-size:var(--fs-caption)">failures: {{ (cb as any).failures ?? 0 }}</span>
                </div>
              </template>

              <!-- Top 10 PageRank -->
              <template v-if="gmProTop10.length">
                <NDivider style="margin:8px 0">Top 10 PageRank</NDivider>
                <EChart v-if="top10ChartOption" :option="top10ChartOption" :height="200" />
                <NEmpty v-else description="无图表数据" style="padding:8px 0" />
              </template>

              <!-- 脏节点 -->
              <template v-if="gmProDirty">
                <NDivider style="margin:8px 0">增量维护</NDivider>
                <div style="display:flex;align-items:center;gap:8px">
                  <NTag :type="(gmProDirty.count ?? 0) > 0 ? 'warning' : 'success'" size="small">脏节点: {{ gmProDirty.count ?? 0 }} 个</NTag>
                  <span v-if="(gmProDirty.nodeIds as string[])?.length" class="muted" style="font-size:var(--fs-caption)">{{ (gmProDirty.nodeIds as string[]).slice(0, 3).join(', ') }}{{ (gmProDirty.nodeIds as string[]).length > 3 ? '…' : '' }}</span>
                </div>
              </template>
            </NCard>
          </NGi>

          <!-- 社区概览 -->
          <NGi>
            <NCard title="社区概览" size="small">
              <template v-if="gmProCommunities.length">
                <div style="max-height:260px;overflow-y:auto">
                  <div v-for="c in gmProCommunities.slice(0, 10)" :key="c.communityId" style="display:flex;align-items:center;gap:8px;padding:4px 0;border-bottom:1px solid var(--color-border-subtle)">
                    <span class="mono" style="font-size:11px;min-width:80px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="c.communityId">{{ c.communityId.slice(0, 12) + '…' }}</span>
                    <NTag size="tiny" :bordered="false">{{ c.memberCount }} 成员</NTag>
                    <span style="font-size:var(--fs-caption);color:var(--color-text-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">{{ c.summary?.slice(0, 80) }}{{ c.summary?.length > 80 ? '…' : '' }}</span>
                  </div>
                </div>
                <div v-if="gmProCommunities.length > 10" class="muted" style="font-size:var(--fs-caption);margin-top:4px">共 {{ gmProCommunities.length }} 个社区，仅显示前 10 个</div>
              </template>
              <!-- 有社区但暂无摘要（gm-pro 尚未生成 summaries）时回退展示数量，
                   避免与上方健康概览"社区数=N"矛盾地显示"暂无社区数据" -->
              <NEmpty
                v-else-if="gmProCommunityCount > 0"
                :description="`共 ${gmProCommunityCount} 个社区（暂无摘要）`"
                style="padding:12px 0"
              >
                <template #extra>
                  <span class="muted" style="font-size:var(--fs-caption)">社区已检测到，但摘要尚未生成，请稍后刷新。</span>
                </template>
              </NEmpty>
              <NEmpty v-else description="暂无社区数据" style="padding:12px 0" />
            </NCard>
          </NGi>

          <!-- 检索状态 -->
          <NGi>
            <NCard title="检索状态" size="small">
              <template v-if="memory">
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem label="最近查询"><span class="mono">{{ memory.retrieval?.lastQuery || '—' }}</span></NDescriptionsItem>
                  <NDescriptionsItem label="性能摘要"><span class="mono">{{ memory.retrieval?.perfSummary || '—' }}</span></NDescriptionsItem>
                </NDescriptions>
                <div class="profile-section"><div class="profile-label">图谱适配器</div>
                  <StatusIndicator label="Neo4j" mode="connection" :available="!!memory.graphAdapter?.connected" :failures="memory.graphAdapter?.circuitBreaker?.failures ?? (memory.graphAdapter?.connectFailed ? 1 : 0)" />
                  <div v-if="memory.graphAdapter?.circuitBreaker?.open" class="muted mono" style="color:var(--n-error-color)">熔断已触发 (failures: {{ memory.graphAdapter.circuitBreaker.failures }})</div>
                  <div v-else-if="memory.graphAdapter?.lastError" class="muted mono">{{ memory.graphAdapter.lastError }}</div>
                </div>
                <div class="profile-section" style="margin-top:8px"><div class="profile-label">QMD 熔断器</div>
                  <StatusIndicator label="QMD" :available="memory.retrieval?.qmdCircuitBreaker?.available ?? true" :failures="memory.retrieval?.qmdCircuitBreaker?.failures ?? 0" />
                  <div v-if="memory.retrieval?.qmdCircuitBreaker?.open" class="muted mono" style="color:var(--n-error-color)">熔断已触发 (failures: {{ memory.retrieval.qmdCircuitBreaker.failures }})</div>
                </div>
              </template>
              <NEmpty v-else description="插件未响应" style="padding:12px 0" />
            </NCard>
          </NGi>
        </NGrid>

        <!-- ═══════════════ gm-pro 智能 ═══════════════ -->
        <NDivider title-placement="left" style="margin: 16px 0 12px">gm-pro 智能</NDivider>

        <NGrid :cols="panelCols" :x-gap="12" :y-gap="12" responsive="screen">
          <!-- AutoTuner 调优 -->
          <NGi>
            <NCard title="AutoTuner 调优" size="small">
              <template v-if="gmProTuner">
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem label="启用状态">
                    <NTag size="small" :type="gmProTuner.enabled ? 'success' : 'warning'">
                      {{ gmProTuner.enabled ? '已启用' : '未启用' }}
                    </NTag>
                    <span v-if="!gmProTuner.enabled && gmProTuner.reason" class="muted" style="font-size:var(--fs-caption);margin-left:6px">{{ gmProTuner.reason }}</span>
                  </NDescriptionsItem>
                  <NDescriptionsItem label="数据可用">
                    <NTag size="small" :type="gmProTuner.available ? 'success' : 'warning'">{{ gmProTuner.available ? '是' : '否' }}</NTag>
                    <span v-if="!gmProTuner.available && gmProTuner.reason" class="muted" style="font-size:var(--fs-caption);margin-left:6px">{{ gmProTuner.reason }}</span>
                  </NDescriptionsItem>
                  <template v-if="gmProTuner.available">
                    <NDescriptionsItem label="调优轮次"><span class="mono">{{ gmProTuner.state?.totalRounds ?? '—' }}</span></NDescriptionsItem>
                    <NDescriptionsItem label="快照数"><span class="mono">{{ gmProTuner.state?.snapshots?.length ?? '—' }}</span></NDescriptionsItem>
                  </template>
                </NDescriptions>
              </template>
              <NEmpty v-else description="暂无调优数据" style="padding:12px 0">
                <template #extra>
                  <span class="muted" style="font-size:var(--fs-caption)">请确认 openclaw.json 中 autoTuner 已启用，且 gm-pro 服务可达。</span>
                </template>
              </NEmpty>
            </NCard>
          </NGi>

          <!-- 系统诊断 (Doctor) -->
          <NGi>
            <NCard title="系统诊断 (Doctor)" size="small">
              <template v-if="gmProDoctor">
                <div style="margin-bottom:8px">
                  <NTag :type="gmProDoctorAbnormalCount === 0 ? 'success' : 'error'" size="small">
                    {{ gmProDoctorAbnormalCount === 0 ? '全部正常' : `${gmProDoctorAbnormalCount} 项异常` }}
                  </NTag>
                  <span v-if="gmProDoctorSummary.total" class="muted" style="margin-left:6px;font-size:var(--fs-caption)">
                    正常 {{ gmProDoctorSummary.ok }} · 警告 {{ gmProDoctorSummary.warn }} · 异常 {{ gmProDoctorSummary.error }}
                  </span>
                </div>
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem v-for="c in gmProDoctorChecks" :key="c.name" :label="c.name">
                    <NTag :type="doctorCheckTagType(c.status)" size="small">{{ doctorCheckLabel(c.status) }}</NTag>
                    <span v-if="c.latencyMs != null" class="muted mono" style="margin-left:6px;font-size:var(--fs-caption)">{{ c.latencyMs }}ms</span>
                    <div v-if="c.detail" class="muted" style="font-size:var(--fs-caption);word-break:break-all">{{ c.detail }}</div>
                    <div v-if="c.hint" class="muted" style="font-size:var(--fs-caption);color:var(--color-warning);word-break:break-all">{{ c.hint }}</div>
                  </NDescriptionsItem>
                </NDescriptions>
              </template>
              <NEmpty v-else description="暂无诊断报告" style="padding:12px 0">
                <template #extra>
                  <span class="muted" style="font-size:var(--fs-caption)">{{ gmProDoctorHint }}</span>
                </template>
              </NEmpty>
            </NCard>
          </NGi>

          <!-- 关联矩阵 M -->
          <NGi>
            <AssociationMatrixCard
              :am="gmProAm"
              :loading="gmProAmFetching"
              :is-error="gmProAmError"
              :acting="amActing"
              @save="handleAmSave"
              @load="handleAmLoad"
              @retry="queryClient.invalidateQueries({ queryKey: ['gm-pro-association-matrix'] })"
            />
          </NGi>
        </NGrid>

        <!-- ═══════════════ 运行指标 ═══════════════ -->
        <NDivider title-placement="left" style="margin: 16px 0 12px">运行指标</NDivider>

        <NGrid :cols="panelCols" :x-gap="12" :y-gap="12" responsive="screen">
          <!-- LLM Token 用量 -->
          <NGi>
            <NCard title="LLM Token 用量" size="small">
              <template v-if="gmProUsage">
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem label="总调用次数"><span class="mono">{{ gmProUsage.total?.calls ?? '—' }}</span></NDescriptionsItem>
                  <NDescriptionsItem label="总 Token"><span class="mono">{{ formatTokens(gmProUsage.total?.totalTokens ?? 0) }}</span></NDescriptionsItem>
                  <NDescriptionsItem label="Prompt"><span class="mono">{{ formatTokens(gmProUsage.total?.promptTokens ?? 0) }}</span></NDescriptionsItem>
                  <NDescriptionsItem label="Completion"><span class="mono">{{ formatTokens(gmProUsage.total?.completionTokens ?? 0) }}</span></NDescriptionsItem>
                  <NDescriptionsItem v-if="gmProUsage.byModel" label="模型分布">
                    <div style="max-height:100px;overflow-y:auto">
                      <div v-for="(v, k) in (gmProUsage.byModel as Record<string, any>)" :key="k" style="font-size:var(--fs-caption);padding:2px 0">
                        <span class="mono">{{ k }}:</span> {{ formatTokens(v.totalTokens ?? 0) }}
                      </div>
                    </div>
                  </NDescriptionsItem>
                </NDescriptions>
              </template>
              <NEmpty v-else description="暂无用量数据" style="padding:12px 0">
                <template #extra>
                  <span class="muted" style="font-size:var(--fs-caption)">数据来自 graph-memory-pro /api/usage，每 60s 自动刷新。若持续为空，请确认 gm-pro 已启用 usage 采集（metricsEnabled）。</span>
                </template>
              </NEmpty>
            </NCard>
          </NGi>

          <!-- Cascade -->
          <NGi>
            <NCard title="Cascade" size="small">
              <template v-if="memory">
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem label="arms 数量">{{ memory.cascade?.armsCount ?? 0 }}</NDescriptionsItem>
                  <NDescriptionsItem label="置信阈值">{{ memory.cascade?.confidenceThreshold ?? '—' }}</NDescriptionsItem>
                  <NDescriptionsItem label="Tier1 置信度">
                    <span v-if="cascadeTier1Confidence !== null" class="mono">{{ cascadeTier1Confidence }}</span>
                    <span v-else class="muted">—</span>
                    <NTag v-if="cascadeJudgeSource" size="small" :type="cascadeJudgeSource === 'gm-pro' ? 'success' : 'default'" style="margin-left:6px">{{ cascadeJudgeSource }}</NTag>
                  </NDescriptionsItem>
                </NDescriptions>
                <EChart v-if="cascadeTopArms.length" :option="betaOption" height="220px" aria-label="Cascade Top 10 臂分布" />
                <NEmpty v-else size="small" description="无 arm 数据" style="margin:12px 0" />
              </template>
              <NEmpty v-else description="插件未响应" style="padding:12px 0">
                <template #extra>
                  <span class="muted" style="font-size:var(--fs-caption)">Cascade 臂数据来自插件健康快照（memory.health），每 10s 自动刷新。若持续为空，请确认插件已启用 Cascade / JudgeManager。</span>
                </template>
              </NEmpty>
            </NCard>
          </NGi>

          <!-- 债务调度 -->
          <NGi>
            <NCard title="债务调度" size="small">
              <template v-if="memory">
                <NDescriptions :column="1" size="small" label-placement="left" bordered>
                  <NDescriptionsItem label="running">{{ memory.debt?.running ?? 0 }}</NDescriptionsItem>
                  <NDescriptionsItem label="pendingCount">{{ memory.debt?.pendingCount ?? 0 }}</NDescriptionsItem>
                  <NDescriptionsItem label="pollIntervalMs">{{ memory.debt?.pollIntervalMs ?? 0 }}</NDescriptionsItem>
                  <NDescriptionsItem label="maxConcurrent">{{ memory.debt?.maxConcurrent ?? 0 }}</NDescriptionsItem>
                </NDescriptions>
              </template>
              <NEmpty v-else description="插件未响应" style="padding:12px 0" />
            </NCard>
          </NGi>

          <!-- 用户画像 -->
          <NGi>
            <NCard title="用户画像" size="small">
              <template v-if="memory">
                <div class="profile-section">
                  <div class="profile-label">技术栈 Top5</div>
                  <NSpace :size="4" v-if="topTechStack.length">
                    <NTag v-for="t in topTechStack" :key="t.name" size="small" type="info">{{ t.name }} ({{ t.weight }})</NTag>
                  </NSpace>
                  <span v-else class="muted">—</span>
                </div>
                <div class="profile-section">
                  <div class="profile-label">场景 Top5</div>
                  <NSpace :size="4" v-if="topScenario.length">
                    <NTag v-for="s in topScenario" :key="s.name" size="small" type="success">{{ s.name }} ({{ s.weight }})</NTag>
                  </NSpace>
                  <span v-else class="muted">—</span>
                </div>
                <div class="profile-section">
                  <span class="profile-label">语言：</span>
                  <NTag size="small">{{ userLanguage }}</NTag>
                </div>
              </template>
              <NEmpty v-else description="插件未响应" style="padding:12px 0" />
            </NCard>
          </NGi>
        </NGrid>
      </NTabPane>

      <!-- ===== Tab 3: MoA 性能 ===== -->
      <NTabPane
        name="moa"
        tab="🤖 MoA 多模型"
        display-directive="show"
      >
        <div v-if="moaPerfLoading && !moaPerf" class="chart-loading">
          <NSpin size="small" />
        </div>

        <template v-else-if="moaPerf">
          <!-- MoA 状态徽章：最近一次运行状态 + 成功率 + fallback 次数 -->
          <div class="moa-badge-bar">
            <MoaStatusBadge />
          </div>

          <!-- KPI 概览行 -->
          <NGrid :cols="'1 s:2 m:3'" :x-gap="12" :y-gap="12" responsive="screen" style="margin-bottom: 16px">
            <NGi>
              <KpiCard label="总运行次数" :value="moaPerf.totalRuns" :threshold="0">
                <template #detail>
                  <NSpace :size="4">
                    <NTag size="tiny" type="success">{{ moaPerf.successRuns }} 成功</NTag>
                    <NTag v-if="moaPerf.failedRuns > 0" size="tiny" type="error">{{ moaPerf.failedRuns }} 失败</NTag>
                    <NTag v-if="moaPerf.fallbackCount > 0" size="tiny" type="warning">{{ moaPerf.fallbackCount }} 回退</NTag>
                  </NSpace>
                </template>
              </KpiCard>
            </NGi>
            <NGi>
              <KpiCard
                label="成功率"
                :value="moaPerf.totalRuns > 0 ? moaSuccessRate : 0"
                unit="%"
                :threshold="90"
              >
                <template #detail>
                  <NTag size="tiny" :type="moaSuccessRateType">{{ moaSuccessRate >= 90 ? '健康' : moaSuccessRate >= 70 ? '注意' : '告警' }}</NTag>
                </template>
              </KpiCard>
            </NGi>
            <NGi>
              <KpiCard
                label="平均耗时"
                :value="Math.round(moaPerf.avgTotalMs / 1000)"
                unit="s"
                :threshold="120"
              >
                <template #detail>
                  <span class="muted">参考 {{ formatMs(moaPerf.avgRefMs) }} / 聚合 {{ formatMs(moaPerf.avgAggMs) }}</span>
                </template>
              </KpiCard>
            </NGi>
          </NGrid>
          <NGrid :cols="'1 s:2 m:3'" :x-gap="12" :y-gap="12" responsive="screen" style="margin-bottom: 16px">
            <NGi>
              <KpiCard
                label="Token 消耗"
                :value="moaPerf.totalTokens"
              >
                <template #detail>
                  <span class="muted">平均 {{ formatTokens(moaPerf.avgTokens) }}/次 · 效率 {{ moaPerf.tokenEfficiency }} 字符/Token</span>
                </template>
              </KpiCard>
            </NGi>
            <NGi>
              <KpiCard
                label="平均复杂度"
                :value="moaPerf.avgComplexityScore"
                :threshold="0.6"
              >
                <template #detail>
                  <NTag size="tiny" :type="moaPerf.avgComplexityScore >= 0.7 ? 'error' : moaPerf.avgComplexityScore >= 0.4 ? 'warning' : 'info'">
                    {{ moaPerf.avgComplexityScore >= 0.7 ? '高' : moaPerf.avgComplexityScore >= 0.4 ? '中' : '低' }}
                  </NTag>
                </template>
              </KpiCard>
            </NGi>
            <NGi>
              <KpiCard
                label="平均响应"
                :value="moaPerf.avgResponseLen"
                unit="字符"
              />
            </NGi>
          </NGrid>

          <!-- 复杂度百分位：全量 + MoA 触发 双行 -->
          <NCard title="复杂度百分位" size="small" style="margin-bottom: 16px">
            <NGrid :cols="'1 s:2 m:4'" :x-gap="12" :y-gap="6" responsive="screen">
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">全量 P50</span>
                <div class="mono" style="font-weight: 600">{{ moaPerf.allComplexityPercentiles.p50.toFixed(3) }}</div>
              </NGi>
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">全量 P90</span>
                <div class="mono" style="font-weight: 600">{{ moaPerf.allComplexityPercentiles.p90.toFixed(3) }}</div>
              </NGi>
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">全量 P95</span>
                <div class="mono" style="font-weight: 600">{{ moaPerf.allComplexityPercentiles.p95.toFixed(3) }}</div>
              </NGi>
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">全量 P99</span>
                <div class="mono" style="font-weight: 600">{{ moaPerf.allComplexityPercentiles.p99.toFixed(3) }}</div>
              </NGi>
            </NGrid>
            <NDivider style="margin: 8px 0" />
            <NGrid :cols="'1 s:2 m:4'" :x-gap="12" :y-gap="6" responsive="screen">
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">MoA P50</span>
                <div class="mono" style="font-weight: 600; color: var(--color-danger)">{{ moaPerf.complexityPercentiles.p50.toFixed(3) }}</div>
              </NGi>
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">MoA P90</span>
                <div class="mono" style="font-weight: 600; color: var(--color-danger)">{{ moaPerf.complexityPercentiles.p90.toFixed(3) }}</div>
              </NGi>
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">MoA P95</span>
                <div class="mono" style="font-weight: 600; color: var(--color-danger)">{{ moaPerf.complexityPercentiles.p95.toFixed(3) }}</div>
              </NGi>
              <NGi>
                <span class="muted" style="font-size: var(--fs-caption)">MoA P99</span>
                <div class="mono" style="font-weight: 600; color: var(--color-danger)">{{ moaPerf.complexityPercentiles.p99.toFixed(3) }}</div>
              </NGi>
            </NGrid>
          </NCard>

          <!-- 复杂度趋势图 + 分布图 -->
          <NGrid :cols="'1 s:1 m:2'" :x-gap="12" :y-gap="12" responsive="screen" style="margin-bottom: 16px">
            <NGi>
              <NCard size="small" :bordered="true">
                <template #header>
                  <div class="trend-header">
                    <span>复杂度趋势</span>
                    <div class="trend-selectors">
                      <NSelect
                        v-model:value="complexityAggregation"
                        :options="complexityAggOptions"
                        size="tiny"
                        style="width: 90px"
                        placeholder="聚合"
                        aria-label="选择复杂度聚合维度"
                      />
                      <NSelect
                        v-model:value="complexityTimeRange"
                        :options="complexityTimeRangeOptions"
                        size="tiny"
                        style="width: 110px"
                        placeholder="时间范围"
                        aria-label="选择复杂度时间范围"
                      />
                    </div>
                  </div>
                </template>
                <EChart :option="moaComplexityTrendOption" height="300px" :skip-theme="true" aria-label="MoA 复杂度趋势图：全量查询复杂度和 MoA 触发点随时间变化" />
              </NCard>
            </NGi>
            <NGi>
              <NCard title="复杂度分布（全量 vs MoA 触发）" size="small" :bordered="true">
                <EChart :option="moaComplexityDistOption" height="300px" :skip-theme="true" aria-label="MoA 复杂度分布对比柱状图：全量查询与 MoA 触发在低中高三个复杂度区间的分布" />
              </NCard>
            </NGi>
          </NGrid>

          <!-- 延迟百分位 + 阶段耗时分解图 -->
          <NGrid :cols="'1 s:1 m:2'" :x-gap="12" :y-gap="12" responsive="screen" style="margin-bottom: 16px">
            <!-- 延迟百分位 -->
            <NGi>
              <NCard title="延迟百分位（P50/P90/P95/P99）" size="small">
                <template v-if="moaPerf.totalRuns > 0">
                  <NDescriptions :column="2" size="small" label-placement="left" bordered>
                    <NDescriptionsItem label="P50 总耗时">
                      <span class="mono">{{ formatMs(moaPerf.latencyPercentiles.p50) }}</span>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P50 参考">
                      <span class="mono">{{ formatMs(moaPerf.refLatencyPercentiles.p50) }}</span>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P90 总耗时">
                      <span class="mono">{{ formatMs(moaPerf.latencyPercentiles.p90) }}</span>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P90 参考">
                      <span class="mono">{{ formatMs(moaPerf.refLatencyPercentiles.p90) }}</span>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P95 总耗时">
                      <NTag size="tiny" :type="moaPerf.latencyPercentiles.p95 > 120000 ? 'warning' : 'default'">
                        {{ formatMs(moaPerf.latencyPercentiles.p95) }}
                      </NTag>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P95 聚合">
                      <span class="mono">{{ formatMs(moaPerf.aggLatencyPercentiles.p95) }}</span>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P99 总耗时">
                      <NTag size="tiny" :type="moaPerf.latencyPercentiles.p99 > 300000 ? 'error' : 'warning'">
                        {{ formatMs(moaPerf.latencyPercentiles.p99) }}
                      </NTag>
                    </NDescriptionsItem>
                    <NDescriptionsItem label="P99 聚合">
                      <span class="mono">{{ formatMs(moaPerf.aggLatencyPercentiles.p99) }}</span>
                    </NDescriptionsItem>
                  </NDescriptions>
                </template>
                <NEmpty v-else description="暂无数据" style="padding: 12px 0" />
              </NCard>
            </NGi>

            <!-- 延迟阶段分解图 -->
            <NGi>
              <NCard title="最近 10 次延迟阶段分解" size="small" :bordered="true">
                <EChart :option="moaLatencyPhaseOption" height="300px" :skip-theme="true" aria-label="MoA 最近 10 次延迟阶段分解堆叠柱状图：参考模型和聚合模型耗时对比" />
              </NCard>
            </NGi>
          </NGrid>

          <!-- 模型级指标 + 错误分布 -->
          <NGrid :cols="'1 s:1 m:2'" :x-gap="12" :y-gap="12" responsive="screen" style="margin-bottom: 16px">
            <!-- 模型级细粒度指标 -->
            <NGi>
              <NCard title="模型级指标" size="small">
                <template v-if="moaPerf.modelBreakdown.length > 0">
                  <div class="model-table-wrap">
                    <table class="model-table">
                      <thead>
                        <tr>
                          <th>模型</th>
                          <th>次数</th>
                          <th>成功率</th>
                          <th>P50</th>
                          <th>P95</th>
                          <th>Avg Tokens</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="m in moaPerf.modelBreakdown" :key="m.model">
                          <td class="mono model-name-cell">{{ m.model }}</td>
                          <td class="num">{{ m.runCount }}</td>
                          <td class="num">
                            <NTag size="tiny" :type="m.runCount > 0 && m.successCount / m.runCount >= 0.9 ? 'success' : 'warning'">
                              {{ m.runCount > 0 ? ((m.successCount / m.runCount) * 100).toFixed(0) + '%' : '--' }}
                            </NTag>
                          </td>
                          <td class="num">{{ formatMs(m.p50LatencyMs) }}</td>
                          <td class="num">{{ formatMs(m.p95LatencyMs) }}</td>
                          <td class="num">{{ formatTokens(m.avgTokens) }}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </template>
                <NEmpty v-else description="暂无模型级数据" style="padding: 12px 0" />
              </NCard>
            </NGi>

            <!-- 错误分布 -->
            <NGi>
              <NCard title="错误类型分布" size="small">
                <template v-if="moaErrorItems.length > 0">
                  <div class="error-list">
                    <div v-for="[type, count] in moaErrorItems" :key="type" class="error-item">
                      <NTag size="small" type="error">{{ type }}</NTag>
                      <span class="error-count">{{ count }} 次</span>
                      <div class="error-bar-track">
                        <div
                          class="error-bar-fill"
                          :style="{ width: moaPerf.failedRuns > 0 ? ((count / moaPerf.failedRuns) * 100).toFixed(0) + '%' : '0%' }"
                        />
                      </div>
                    </div>
                  </div>
                </template>
                <NEmpty v-else description="暂无错误记录" style="padding: 12px 0" />
              </NCard>
            </NGi>
          </NGrid>

          <!-- 最近运行记录 -->
          <NCard title="最近运行记录" size="small">
            <template v-if="moaPerf.recentRuns.length === 0">
              <NEmpty description="暂无 MoA 运行记录" style="padding: 24px 0">
                <template #extra>
                  <NButton size="small" @click="() => $router.push('/settings')">前往设置启用 MoA</NButton>
                </template>
              </NEmpty>
            </template>
            <NTable
              v-else
              :data="moaPerf.recentRuns"
              :columns="moaRunsColumns"
              :bordered="false"
              :single-line="false"
              size="small"
              :max-height="400"
              striped
            />
          </NCard>
        </template>

        <NEmpty v-else description="暂无 MoA 性能数据" style="padding: 24px 0">
          <template #extra>
            <NButton size="small" @click="() => $router.push('/settings')">前往设置启用 MoA</NButton>
          </template>
        </NEmpty>
      </NTabPane>
    </NTabs>
  </div>
</template>

<style scoped>
.monitor-view {
  width: 100%;
}
.monitor-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
}
.header-right {
  display: flex;
  align-items: center;
  gap: 8px;
}
.last-updated {
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
}
.profile-section {
  margin-bottom: var(--space-sm);
}
.profile-label {
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  margin-bottom: var(--space-xs);
}
/* .muted / .mono 已在 tokens.css 全局定义，此处不重复 */
.layer-grid {
  display: grid;
  /* L5 修复：窄屏自适应列数（auto-fill + minmax），避免 5 列在窄屏被挤压 */
  grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
  gap: var(--space-sm);
  /* 重置 ul 默认样式 */
  list-style: none;
  margin: 0;
  padding: 0;
}
.layer-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-xs);
  padding: var(--space-sm) 2px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}
/* 状态点：符号居中，双重编码（颜色+符号） */
.layer-cell .dot {
  width: 16px;
  height: 16px;
  border-radius: var(--radius-full);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: var(--fs-caption);
  font-weight: 700;
  line-height: 1;
  /* v2.3.3：符号色用染色表面（白 + 1.5% 蓝），避免纯白 */
  color: var(--color-surface);
}
.layer-cell .dot-ok {
  background: var(--color-success);
  box-shadow: 0 0 4px color-mix(in srgb, var(--color-success) 60%, transparent);
}
.layer-cell .dot-fail {
  background: var(--color-danger);
  box-shadow: 0 0 4px color-mix(in srgb, var(--color-danger) 60%, transparent);
}
.layer-label {
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
}
/* M10 修复：统一加载态样式（图表/卡片内居中 spinner） */
.chart-loading,
.card-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px 0;
}
/* 时序图时间粒度选择器工具条 */
.granularity-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
}
.granularity-label {
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  white-space: nowrap;
}
.granularity-hint {
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  opacity: 0.8;
  /* UX-5: 防止选择器提示文字溢出 */
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 300px;
  flex-shrink: 1;
}

/* ===== P1-6: 当前压力 Tier 徽章 ===== */
.tier-badge-bar {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  margin-top: 12px;
  flex-wrap: wrap;
}
.tier-badge-label {
  font-size: var(--fs-body);
  color: var(--color-text-secondary);
}
.tier-badge-detail {
  font-size: var(--fs-caption);
  margin-left: var(--space-xs);
}

/* ===== P1-2: 熔断器状态 ===== */
.cb-row {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
}
.cb-label {
  flex: 1;
  font-size: var(--fs-body);
}
.cb-failures {
  font-size: var(--fs-caption);
}

/* ===== P1-6: tier 分布趋势 ===== */
.tier-current-dist {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.tier-dist-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.tier-dist-label {
  width: 56px;
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  flex-shrink: 0;
}
.tier-dist-value {
  width: 90px;
  font-size: var(--fs-caption);
  text-align: right;
  flex-shrink: 0;
}
.tier-trend-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.tier-trend-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.tier-trend-time {
  width: 60px;
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  flex-shrink: 0;
}
.tier-trend-bar {
  flex: 1;
  height: 10px;
  display: flex;
  border-radius: 5px;
  overflow: hidden;
  background: var(--color-border);
}
.tier-trend-seg {
  height: 100%;
  transition: width 0.4s ease;
}
.tier-trend-seg.tier-low {
  background: var(--color-success);
}
.tier-trend-seg.tier-medium {
  background: var(--color-warning);
}
.tier-trend-seg.tier-high {
  background: var(--color-danger);
}
.tier-trend-total {
  width: 32px;
  font-size: var(--fs-caption);
  text-align: right;
  flex-shrink: 0;
}

/* 复杂度趋势图头部 */
.trend-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
}
.trend-selectors {
  display: flex;
  align-items: center;
  gap: 6px;
}

/* ===== MoA 性能样式 ===== */
/* 状态徽章容器：紧贴 KPI 行上方，左对齐 */
.moa-badge-bar {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
}

.stat-card {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.stat-label {
  font-size: var(--fs-caption);
  color: var(--color-text-tertiary);
}

.stat-value {
  font-size: var(--fs-h2);
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}

.stat-detail {
  display: flex;
  gap: 6px;
  align-items: center;
}

.phase-bars {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.phase-bar-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.phase-bar-label {
  width: 80px;
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  text-align: right;
  flex-shrink: 0;
}

.phase-bar-track {
  flex: 1;
  height: 10px;
  background: var(--color-border);
  border-radius: 5px;
  overflow: hidden;
}

.phase-bar-fill {
  height: 100%;
  border-radius: 5px;
  transition: width 0.5s ease;
}

.phase-bar-ref {
  background: var(--color-primary);
}

.phase-bar-agg {
  background: var(--color-success);
}

.phase-bar-value {
  width: 60px;
  font-size: var(--fs-caption);
  font-variant-numeric: tabular-nums;
  color: var(--color-text-secondary);
  flex-shrink: 0;
}

/* 模型级指标表格 */
.model-table-wrap {
  overflow-x: auto;
}

.model-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--fs-caption);
}

.model-table th {
  text-align: left;
  padding: 6px 8px;
  border-bottom: 1px solid var(--color-border);
  color: var(--color-text-tertiary);
  font-weight: 500;
  white-space: nowrap;
}

.model-table td {
  padding: 6px 8px;
  border-bottom: 1px solid var(--color-border-subtle);
}

.model-name-cell {
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 错误分布 */
.error-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.error-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.error-count {
  font-size: var(--fs-caption);
  font-variant-numeric: tabular-nums;
  color: var(--color-text-secondary);
  min-width: 40px;
}

.error-bar-track {
  flex: 1;
  height: 6px;
  background: var(--color-border);
  border-radius: 3px;
  overflow: hidden;
}

.error-bar-fill {
  height: 100%;
  border-radius: 3px;
  background: var(--color-danger);
  transition: width 0.5s ease;
}

/* 运行记录表格 */
.run-table {
  overflow-x: auto;
}

.run-table-header {
  display: flex;
  font-size: var(--fs-caption);
  font-weight: 500;
  color: var(--color-text-tertiary);
  padding: 8px 0;
  border-bottom: 1px solid var(--color-border);
  gap: 8px;
}

.run-row {
  display: flex;
  padding: 8px 0;
  border-bottom: 1px solid var(--color-border-subtle);
  font-size: var(--fs-body);
  gap: 8px;
  align-items: center;
}

.run-row:last-child {
  border-bottom: none;
}

.run-failed {
  background: rgba(208, 48, 80, 0.04);
}

.col-time { width: 70px; flex-shrink: 0; }
.col-query { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.col-mode { width: 55px; flex-shrink: 0; text-align: center; }
.col-status { width: 45px; flex-shrink: 0; text-align: center; }
.col-total { width: 65px; flex-shrink: 0; text-align: right; }
.col-ref { width: 100px; flex-shrink: 0; text-align: right; }
.col-agg { width: 95px; flex-shrink: 0; text-align: right; }
.col-tokens { width: 55px; flex-shrink: 0; text-align: right; }

.num {
  font-variant-numeric: tabular-nums;
}

/* UX-14: 窄屏图表 X 轴标签自适应 */
@media (max-width: 768px) {
  .granularity-bar {
    flex-wrap: wrap;
  }
  .trend-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }
  .trend-selectors {
    width: 100%;
  }
  /* UX-15: 窄屏 MoA 趋势图文字重叠 */
  .model-table-wrap {
    font-size: var(--fs-caption);
  }
  .model-table th,
  .model-table td {
    padding: 4px 4px;
  }
  .model-name-cell {
    max-width: 80px;
  }
}

/* G-5.1: gm-pro 健康概览统计单元 */
.health-stat {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 4px 0;
}
.health-stat-label {
  font-size: var(--fs-caption);
  color: var(--color-text-tertiary);
}
.health-stat-value {
  font-size: var(--fs-body);
  font-weight: 600;
}
.text-warning {
  color: var(--color-warning);
}
.text-danger {
  color: var(--color-danger);
}

/* ===== gm-pro 服务表格 ===== */
.svc-header-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}
.svc-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--fs-caption);
}
.svc-table th {
  text-align: left;
  padding: 6px 8px;
  border-bottom: 1px solid var(--color-border);
  color: var(--color-text-tertiary);
  font-weight: 500;
  white-space: nowrap;
}
.svc-table td {
  padding: 5px 8px;
  border-bottom: 1px solid var(--color-border-subtle);
  vertical-align: middle;
}
.svc-name {
  font-weight: 500;
  min-width: 90px;
}
.svc-detail {
  max-width: 280px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.svc-detail-kv {
  display: inline-block;
  margin-right: 12px;
  font-size: var(--fs-caption);
}
</style>
