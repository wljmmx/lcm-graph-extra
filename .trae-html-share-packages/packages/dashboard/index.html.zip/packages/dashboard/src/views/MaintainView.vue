<script setup lang="ts">
/**
 * 维护操作页（模块 4）。
 *
 * 布局（设计文档 4.4 节）：
 *   9 张操作卡片网格（NGrid cols=2 响应式） + 底部固定操作日志区
 *
 * 写路径：所有操作通过 POST /api/mcp/invoke 走 MCP（P3 已实现）。
 * 本模块复用 src/api/maintain.ts 中的语义化封装函数。
 *
 * 状态管理：
 *   - logs: reactive 数组，新操作 unshift 到顶部，裁剪到 20 条
 *   - loadingMap: reactive<Record<cardKey, boolean>>，每张卡片独立 loading
 *   - useMutation 包装 invoke 调用，onMutate/onSuccess/onError 维护日志
 *
 * 安全约束（设计文档 6.3 节）：
 *   - restore 强制 dryRun 默认 true（前端表单默认勾选）
 *   - restore 三次确认（confirmLevel=2）
 *   - reset_breaker / sync repair / compact / maintain / ttl_cleanup / import 二次确认
 *   - 危险操作（restore / reset_breaker / sync repair）按钮 type=error
 */
import { computed, onMounted, onUnmounted, reactive, ref, watch } from 'vue';
import { useMutation, useQuery } from '@tanstack/vue-query';
import { NGrid, NGi, NSpace, NInput, NInputNumber, NSelect, NSwitch, NFormItem, NAlert, NTag, NText, NProgress, useMessage } from 'naive-ui';
import OperationCard from '../components/OperationCard.vue';
import OperationLog, { type OperationLogEntry } from '../components/OperationLog.vue';
import OperationRecentHistory from '../components/OperationRecentHistory.vue';
import {
  invokeMaintain,
  invokeDiagnose,
  invokeDistill,
  invokeDistillRetry,
  invokeBackfill,
  invokeCompact,
  invokeResetBreaker,
  invokeBackup,
  invokeRestore,
  invokeSync,
  invokeImport,
  invokePin,
  invokeForget,
  invokeExtractRebuild,
  fetchExtractRebuildProgress,
  type ExtractRebuildProgress,
  invokeBootstrap,
  invokeReembed,
  invokeMaintainAsync,
  fetchOperationLogs,
  type OperationLogRecord,
} from '../api/maintain';
import type { GmProReembedTaskSnapshot, GmProMaintainTaskSnapshot } from '../api/gm-pro';
import { formatDateTime } from '../utils/format';
import type { McpInvokeResponse } from '../api/experience';
import { extractDetails, extractText } from '../api/experience';

const message = useMessage();

// ===== 各卡片表单状态 =====

// 卡片 2：蒸馏
const distillLimit = ref<number>(50);

// 卡片 2.1：重试失败经验
const retryMode = ref<'exhausted' | 'all'>('exhausted');
const retryModeOptions = [
  { label: '仅重试已耗尽 (exhausted)', value: 'exhausted' },
  { label: '重试全部失败 (all)', value: 'all' },
];

// 卡片 2.5：经验回溯
const backfillLimit = ref<number>(20);
const backfillForce = ref<boolean>(false);

// 卡片 3：compact
const compactConversationId = ref<number | null>(null);

// 卡片 4：重置熔断器
const breakerName = ref<string>('lcm');
const breakerOptions = [
  { label: 'LCM (lossless-claw)', value: 'lcm' },
  { label: 'QMD (memory file engine)', value: 'qmd' },
  { label: 'Neo4j (graph-memory-pro)', value: 'neo4j' },
];

// 卡片 5.1：节点置顶（lcmg_pin）
const pinNodeId = ref<string>('');
const pinUnpin = ref<boolean>(false);

// 卡片 5.2：主动遗忘（lcmg_forget）
const forgetNodeId = ref<string>('');
const forgetQuery = ref<string>('');
const forgetMode = ref<'soft' | 'hard'>('soft');
const forgetConfirm = ref<boolean>(false);
const forgetModeOptions = [
  { label: '软遗忘 (soft, 降权仍可检索)', value: 'soft' },
  { label: '硬遗忘 (hard, 标记 superseded)', value: 'hard' },
];
// hard 模式才视为危险操作 + 二次确认
const forgetDanger = computed(() => forgetMode.value === 'hard');
const forgetConfirmLevel = computed<0 | 1 | 2>(() => (forgetMode.value === 'hard' ? 2 : 1));

// 卡片 6：备份
const todayStamp = (() => {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}${mm}${dd}`;
})();
const backupOutputPath = ref<string>(`~/.openclaw/backup-${todayStamp}.json`);

// 卡片 7：恢复（强制 dryRun 默认 true）
const restoreBackupPath = ref<string>('');
const restoreTargets = ref<string>('all');
const restoreDryRun = ref<boolean>(true);
const restoreTargetsOptions = [
  { label: '全部 (all)', value: 'all' },
  { label: '仅 Neo4j (neo4j_only)', value: 'neo4j_only' },
  { label: '仅 LCM (lcm_only)', value: 'lcm_only' },
  { label: '仅文件 (files_only)', value: 'files_only' },
];

// H6 修复：路径常驻校验状态（替代一闪而过的 toast）
const backupPathError = computed(() => validateOpenclawPath(backupOutputPath.value));
const restorePathError = computed(() => validateOpenclawPath(restoreBackupPath.value));

// 卡片 8：同步修复
const syncMode = ref<'check' | 'repair'>('check');
const syncDryRun = ref<boolean>(true);
const syncModeOptions = [
  { label: '检查 (check, 只读审计)', value: 'check' },
  { label: '修复 (repair, 实际执行)', value: 'repair' },
];
// repair 模式才视为危险操作 + 二次确认
const syncDanger = computed(() => syncMode.value === 'repair');
const syncConfirmLevel = computed<0 | 1>(() => (syncMode.value === 'repair' ? 1 : 0));

// 卡片 9：历史导入
const importSource = ref<string>('all');
const importLimit = ref<number>(100);
const importSourceOptions = [
  { label: '全部 (all)', value: 'all' },
  { label: 'LCM 消息 (lcm_messages)', value: 'lcm_messages' },
  { label: '记忆文件 (memory_files)', value: 'memory_files' },
];

// 卡片 9.5：三级节点重建（v2.8.1 新增）
// gm-pro 仅在传入 progressPath 时落盘进度，故留空时使用默认路径，保证「重建写入」与「进度轮询读取」一致。
// 单会话（rebuild）和全部重建（rebuild-all）使用不同默认路径，避免两种格式混写（gm-pro 已加 kind 校验，
// 但物理隔离更稳妥）。
const DEFAULT_REBUILD_SESSION_PATH = '/tmp/rebuild-session.json';
const DEFAULT_REBUILD_ALL_PATH = '/tmp/rebuild-all.json';
const extractSessionKey = ref<string>('');
const extractLimit = ref<number>(50);
const extractConcurrency = ref<number>(4);
const extractSessionConcurrency = ref<number>(2);
const extractMode = ref<'llm' | 'heuristic'>('heuristic');
const extractLimitSessions = ref<number>(0);
const extractPageSize = ref<number>(2000);
const extractWriteBatchSize = ref<number>(500);
const extractProgressPath = ref<string>('');

/** 根据是否有 sessionKey 选择默认 progressPath：单会话→rebuild-session.json，全部→rebuild-all.json。
 *  用户手动填写了 progressPath 时优先用用户值。 */
const effectiveProgressPath = computed(() => {
  const userPath = extractProgressPath.value?.trim();
  if (userPath) return userPath;
  return extractSessionKey.value?.trim()
    ? DEFAULT_REBUILD_SESSION_PATH
    : DEFAULT_REBUILD_ALL_PATH;
});

// 卡片 9.5：重建实时进度（轮询 GET /api/extract-rebuild/progress，双进度条）
const extractProgress = ref<ExtractRebuildProgress | null>(null);
let extractProgressTimer: ReturnType<typeof setInterval> | null = null;

/** 批次进度（会话粒度）：当前批次 / 总批次 */
const extractBatchPercent = computed(() => {
  const p = extractProgress.value;
  if (!p || p.totalBatches <= 0) return 0;
  return Math.min(100, Math.round((p.currentBatch / p.totalBatches) * 100));
});

/** 总进度（轮次粒度）：已提取轮次 / 总轮次，无轮次数据时回退会话进度 */
const extractTotalPercent = computed(() => {
  const p = extractProgress.value;
  if (!p) return 0;
  if (p.totalTurns > 0) return Math.min(100, Math.round((p.processedTurns / p.totalTurns) * 100));
  if (p.totalSessions > 0) return Math.min(100, Math.round((p.processedSessions / p.totalSessions) * 100));
  return 0;
});

async function pollExtractProgress(): Promise<void> {
  try {
    // 与 executeExtractRebuild 的路径保持一致，否则「重建写入路径」与「进度读取路径」不匹配。
    const res = await fetchExtractRebuildProgress(effectiveProgressPath.value);
    // 避免 null 覆盖上一次已拿到的进度（重建刚开始时文件可能尚未落盘）
    if (res.progress) extractProgress.value = res.progress;
    if (res.progress?.done) stopExtractPolling();
  } catch {
    // 轮询失败静默（保留上次进度），避免干扰主流程
  }
}

function startExtractPolling(): void {
  stopExtractPolling();
  extractProgress.value = null;
  void pollExtractProgress();
  extractProgressTimer = setInterval(() => { void pollExtractProgress(); }, 2000);
}

function stopExtractPolling(): void {
  if (extractProgressTimer) {
    clearInterval(extractProgressTimer);
    extractProgressTimer = null;
  }
}

// 重建卡片进入 loading 即开始轮询，结束即停止
// 注意：必须放在 loadingMap 声明之后（依赖 loadingMap）
onUnmounted(stopExtractPolling);

// 卡片 10：Bootstrap 反馈（v2.3.5 新增）
const bootstrapLimit = ref<number>(100);

// 卡片 11：重新向量化（gm-pro，clear 开关）
const reembedClear = ref<boolean>(false);
// gm_reembed 异步化：轮询期间的最新任务快照（进度条/批次/失败数显示）
const reembedProgress = ref<GmProReembedTaskSnapshot | null>(null);
// 卡片 1：图谱维护（gm-maintain 异步化，与 reembed 对称）
const maintainProgress = ref<GmProMaintainTaskSnapshot | null>(null);

// ===== 路径安全校验（前端轻量校验，后端 POST /api/mcp/invoke 有硬墙兜底） =====

/**
 * 校验路径必须位于 ~/.openclaw 之下。
 * 浏览器无法获知真实 home 目录，仅做前缀 + 遍历检查；
 * 后端用 path.resolve(os.homedir(), ...) 做权威校验。
 *
 * @returns null 表示通过，否则为错误文案
 */
function validateOpenclawPath(p: string): string | null {
  const trimmed = p.trim();
  if (!trimmed) return '路径不能为空';
  // 统一为正斜杠便于匹配
  const normalized = trimmed.replace(/\\/g, '/');
  const prefix = '~/.openclaw';
  const ok = normalized === prefix || normalized.startsWith(prefix + '/');
  if (!ok) return `路径必须位于 ${prefix} 之下`;
  // 拒绝路径遍历段
  if (/(^|\/)\.\.(\/|$)/.test(normalized)) return '路径不能包含 .. 段';
  return null;
}

// ===== 日志 + loading 状态 =====

const logs = ref<OperationLogEntry[]>([]);
const loadingMap = reactive<Record<string, boolean>>({});
// 重建卡片进入 loading 即开始轮询，结束即停止（依赖 loadingMap，须在其声明后）
watch(
  () => loadingMap.extract_rebuild,
  (loading) => {
    if (loading) startExtractPolling();
    else stopExtractPolling();
  },
);
/** 每张卡片最近一次完成的执行结果（用于卡片内摘要展示） */
const lastResultMap = reactive<Record<string, {
  status: 'success' | 'error';
  details: OperationLogEntry['details'];
  text: OperationLogEntry['text'];
}>>({});
let nextLogId = 1;
// cardKey → 当前 running 日志 ID（用于 onSuccess/onError 回填）
const pendingLogIds = new Map<string, number>();
const MAX_LOGS = 20;

interface MutationVars {
  cardKey: string;
  tool: string;
  params: Record<string, unknown>;
  invokeFn: () => Promise<McpInvokeResponse>;
}

/** 推入一条 running 日志并返回其 ID（同时裁剪到最近 MAX_LOGS 条） */
function pushRunningLog(cardKey: string, tool: string, params: Record<string, unknown>): number {
  const id = nextLogId++;
  const entry: OperationLogEntry = {
    id,
    tool,
    params,
    status: 'running',
    ts: Date.now(),
  };
  logs.value.unshift(entry);
  if (logs.value.length > MAX_LOGS) {
    logs.value.length = MAX_LOGS;
  }
  return id;
}

/** 据 ID 回填日志结果 */
function patchLog(id: number, patch: Partial<OperationLogEntry>): void {
  const idx = logs.value.findIndex((l) => l.id === id);
  if (idx === -1) return;
  logs.value[idx] = { ...logs.value[idx], ...patch };
}

const mutation = useMutation<McpInvokeResponse, Error, MutationVars>({
  mutationFn: (vars) => vars.invokeFn(),
  onMutate: (vars) => {
    const logId = pushRunningLog(vars.cardKey, vars.tool, vars.params);
    pendingLogIds.set(vars.cardKey, logId);
    loadingMap[vars.cardKey] = true;
  },
  onSuccess: (data, vars) => {
    const logId = pendingLogIds.get(vars.cardKey);
    if (logId !== undefined) {
      const log = logs.value.find((l) => l.id === logId);
      const details = extractDetails(data.result);
      const text = extractText(data.result);
      const status = data.ok ? 'success' as const : 'error' as const;
      patchLog(logId, {
        status,
        result: data.result,
        error: data.error,
        details,
        text,
        durationMs: log ? Date.now() - log.ts : 0,
      });
      pendingLogIds.delete(vars.cardKey);
      // 记录卡片级摘要
      lastResultMap[vars.cardKey] = { status, details, text };
    }
    loadingMap[vars.cardKey] = false;
    // 后端已持久化该次调用，刷新卡片历史区
    void refreshHistory();
  },
  onError: (err, vars) => {
    const logId = pendingLogIds.get(vars.cardKey);
    if (logId !== undefined) {
      const log = logs.value.find((l) => l.id === logId);
      patchLog(logId, {
        status: 'error',
        error: err.message,
        durationMs: log ? Date.now() - log.ts : 0,
      });
      pendingLogIds.delete(vars.cardKey);
      lastResultMap[vars.cardKey] = { status: 'error', details: null, text: null };
    }
    loadingMap[vars.cardKey] = false;
    // 后端已持久化该次调用，刷新卡片历史区
    void refreshHistory();
  },
});

// M14 修复：顶部错误条可关闭，且新错误出现时自动恢复显示
const topErrorDismissed = ref(false);
watch(
  () => mutation.error.value,
  () => { topErrorDismissed.value = false; },
);

/**
 * 统一执行入口（P1 竞态修复）。
 *
 * onMutate 由 TanStack Query 异步调度，若用户在首次调用的 onMutate
 * 真正执行前再次触发同一卡片，pendingLogIds.set 会覆盖首条 logId，
 * 导致首条 running 日志永不被回填。此处同步置位 loadingMap 作为硬守卫，
 * 在 mutate 调用前就拒绝重入。
 */
function runMutation(vars: MutationVars): void {
  if (loadingMap[vars.cardKey]) return;
  loadingMap[vars.cardKey] = true;
  mutation.mutate(vars);
}

// ===== 持久化操作历史（P1-3 / P1-4：读取 /api/operation-logs，跨刷新保留） =====

/** 最近拉取的持久化日志（按 ts DESC），供卡片底部“最近执行结果”与 Backup 横幅使用 */
const historyLogs = ref<OperationLogRecord[]>([]);
const historyLoading = ref<boolean>(false);
/** 一次拉取的条数：取较大值以覆盖各 tool 的最近 5 条（多 tool 共享一次请求） */
const HISTORY_FETCH_N = 200;

/**
 * 拉取持久化操作日志。失败静默（历史区为非关键展示，不阻塞主流程）。
 * 后端在 /api/mcp/invoke 返回前已 appendOperationLog，故 mutation 完成后即可刷新到最新。
 */
async function refreshHistory(): Promise<void> {
  historyLoading.value = true;
  try {
    const res = await fetchOperationLogs({ n: HISTORY_FETCH_N });
    historyLogs.value = res.logs ?? [];
  } catch {
    // 拉取失败保留既有数据，不弹 toast 避免干扰
  } finally {
    historyLoading.value = false;
  }
}

/** 按 tool 分组（后端已 DESC，组内直接取头部即“最近”） */
const historyByTool = computed<Record<string, OperationLogRecord[]>>(() => {
  const map: Record<string, OperationLogRecord[]> = {};
  for (const log of historyLogs.value) {
    (map[log.tool] ??= []).push(log);
  }
  return map;
});

/** 取某 tool 的历史切片（最近 n 条） */
function historyOf(tool: string, n: number = 5): OperationLogRecord[] {
  return (historyByTool.value[tool] ?? []).slice(0, n);
}

/** 最近一次备份记录（用于 Backup 卡片顶部横幅） */
const lastBackupLog = computed<OperationLogRecord | null>(() => {
  return historyByTool.value['lcmg_backup']?.[0] ?? null;
});

/** TTL 清理专属历史（过滤 lcmg_maintain 中 source=ttl_cleanup 的条目） */
const ttlCleanupHistory = computed<OperationLogRecord[]>(() => {
  return (historyByTool.value['lcmg_maintain'] ?? []).filter(
    (log) => log.params?.source === 'ttl_cleanup',
  );
});

/** 图谱维护专属历史（排除 TTL 清理条目，与 TTL 卡片区分） */
const maintainHistory = computed<OperationLogRecord[]>(() => {
  return (historyByTool.value['lcmg_maintain'] ?? []).filter(
    (log) => log.params?.source !== 'ttl_cleanup',
  );
});

/** 从备份记录中提取文件路径：优先 params.outputPath */
function backupFilePath(log: OperationLogRecord | null): string | null {
  if (!log) return null;
  const p = log.params?.outputPath;
  return typeof p === 'string' && p.trim() ? p.trim() : null;
}

onMounted(() => {
  void refreshHistory();
});

// ===== 各卡片执行入口（封装 runMutation） =====

function executeMaintain(): void {
  maintainProgress.value = null;
  runMutation({
    cardKey: 'maintain',
    tool: 'lcmg_maintain',
    params: {},
    invokeFn: () => invokeMaintainAsync({
      onProgress: (snap) => {
        maintainProgress.value = snap;
      },
    }),
  });
}

function executeDiagnose(): void {
  runMutation({
    cardKey: 'diagnose',
    tool: 'lcmg_diagnose',
    params: {},
    invokeFn: () => invokeDiagnose(),
  });
}

function executeDistill(): void {
  runMutation({
    cardKey: 'distill',
    tool: 'lcmg_distill',
    params: { limit: distillLimit.value },
    invokeFn: () => invokeDistill(distillLimit.value),
  });
}

function executeDistillRetry(): void {
  runMutation({
    cardKey: 'distill_retry',
    tool: 'lcmg_distill_retry',
    params: { mode: retryMode.value },
    invokeFn: () => invokeDistillRetry(retryMode.value),
  });
}

function executeBackfill(): void {
  runMutation({
    cardKey: 'backfill',
    tool: 'lcmg_backfill',
    params: { limit: backfillLimit.value, force: backfillForce.value },
    invokeFn: () => invokeBackfill(backfillLimit.value, backfillForce.value),
  });
}

function executeCompact(): void {
  const params: Record<string, unknown> = {};
  if (compactConversationId.value !== null && compactConversationId.value !== undefined) {
    params.conversationId = compactConversationId.value;
  }
  runMutation({
    cardKey: 'compact',
    tool: 'lcmg_compact',
    params,
    invokeFn: () => invokeCompact(compactConversationId.value ?? undefined),
  });
}

function executeResetBreaker(): void {
  runMutation({
    cardKey: 'reset_breaker',
    tool: 'lcmg_reset_breaker',
    params: { name: breakerName.value },
    invokeFn: () => invokeResetBreaker(breakerName.value),
  });
}

function executeTtlCleanup(): void {
  // TTL 清理复用 lcmg_maintain（已内置债务表对账 + 孤儿清理），传入 source 参数区分
  const params = { source: 'ttl_cleanup' } as const;
  runMutation({
    cardKey: 'ttl_cleanup',
    tool: 'lcmg_maintain',
    params,
    invokeFn: () => invokeMaintain(params),
  });
}

/**
 * 节点置顶（lcmg_pin）：置顶节点豁免 TTL 清理与自动删除；unpin=true 恢复常规语义。
 * 节点 ID 必填（工具按 id 精确定位）。
 */
function executePin(): void {
  const id = pinNodeId.value.trim();
  if (!id) {
    message.error('请填写节点 ID');
    return;
  }
  runMutation({
    cardKey: 'pin',
    tool: 'lcmg_pin',
    params: { id, unpin: pinUnpin.value },
    invokeFn: () => invokePin(id, pinUnpin.value),
  });
}

/**
 * 主动遗忘（lcmg_forget）：id 或 query 至少填一个；hard 模式需 confirm=true。
 * soft=降权（仍可检索）；hard=标记 superseded（从检索中排除，不可逆）。
 */
function executeForget(): void {
  const id = forgetNodeId.value.trim();
  const query = forgetQuery.value.trim();
  if (!id && !query) {
    message.error('请填写节点 ID 或查询词（至少一项）');
    return;
  }
  if (forgetMode.value === 'hard' && !forgetConfirm.value) {
    message.error('硬遗忘需勾选 confirm 确认（防止误删）');
    return;
  }
  const mode = forgetMode.value;
  runMutation({
    cardKey: 'forget',
    tool: 'lcmg_forget',
    params: {
      ...(id ? { id } : {}),
      ...(query ? { query } : {}),
      mode,
      ...(mode === 'hard' ? { confirm: forgetConfirm.value } : {}),
    },
    invokeFn: () => invokeForget({
      id: id || undefined,
      query: query || undefined,
      mode,
      confirm: forgetConfirm.value,
    }),
  });
}

function executeBackup(): void {
  const err = validateOpenclawPath(backupOutputPath.value);
  if (err) {
    message.error(err);
    return;
  }
  runMutation({
    cardKey: 'backup',
    tool: 'lcmg_backup',
    params: { outputPath: backupOutputPath.value },
    invokeFn: () => invokeBackup(backupOutputPath.value),
  });
}

function executeRestore(): void {
  const err = validateOpenclawPath(restoreBackupPath.value);
  if (err) {
    message.error(err);
    return;
  }
  runMutation({
    cardKey: 'restore',
    tool: 'lcmg_restore',
    params: {
      backupPath: restoreBackupPath.value,
      targets: restoreTargets.value,
      dryRun: restoreDryRun.value,
    },
    invokeFn: () =>
      invokeRestore(restoreBackupPath.value, restoreTargets.value, restoreDryRun.value),
  });
}

function executeSync(): void {
  runMutation({
    cardKey: 'sync',
    tool: 'lcmg_sync',
    params: { mode: syncMode.value, dryRun: syncDryRun.value },
    invokeFn: () => invokeSync(syncMode.value, syncDryRun.value),
  });
}

function executeImport(): void {
  runMutation({
    cardKey: 'import',
    tool: 'lcmg_import',
    params: { source: importSource.value, limit: importLimit.value },
    invokeFn: () => invokeImport(importSource.value, importLimit.value),
  });
}

function executeExtractRebuild(): void {
  // 复用 gm-pro HTTP API：gm-pro 无 thinking 参数（思考开关由 gm-pro 自身配置控制），故不传。
  // progressPath 由 effectiveProgressPath 自动选择：单会话→rebuild-session.json，全部→rebuild-all.json。
  // 用户手动填写时优先用户值。gm-pro 已加 kind 校验防止格式混读，但物理隔离更稳妥。
  extractSessionKey.value = extractSessionKey.value?.trim() ?? '';
  const sessionKey = extractSessionKey.value || undefined;
  const progressPath = effectiveProgressPath.value;
  runMutation({
    cardKey: 'extract_rebuild',
    tool: 'gm_pro_extract_rebuild',
    params: {
      sessionKey,
      limit: extractLimit.value,
      concurrency: extractConcurrency.value,
      sessionConcurrency: extractSessionConcurrency.value,
      mode: extractMode.value,
      limitSessions: extractLimitSessions.value > 0 ? extractLimitSessions.value : undefined,
      pageSize: extractPageSize.value,
      writeBatchSize: extractWriteBatchSize.value,
      progressPath,
    },
    invokeFn: () => invokeExtractRebuild({
      sessionKey,
      limit: extractLimit.value,
      concurrency: extractConcurrency.value,
      sessionConcurrency: extractSessionConcurrency.value,
      mode: extractMode.value,
      limitSessions: extractLimitSessions.value > 0 ? extractLimitSessions.value : undefined,
      pageSize: extractPageSize.value,
      writeBatchSize: extractWriteBatchSize.value,
      progressPath,
    }),
  });
}

function executeBootstrap(): void {
  runMutation({
    cardKey: 'bootstrap',
    tool: 'gm_bootstrap',
    params: { limit: bootstrapLimit.value },
    invokeFn: () => invokeBootstrap(bootstrapLimit.value),
  });
}

function executeReembed(): void {
  reembedProgress.value = null;
  runMutation({
    cardKey: 'reembed',
    tool: 'gm_reembed',
    params: { clear: reembedClear.value },
    invokeFn: () => invokeReembed({
      clear: reembedClear.value,
      onProgress: (snap) => {
        reembedProgress.value = snap;
      },
    }),
  });
}
</script>

<template>
  <div class="maintain-view">
    <div class="maintain-header">
      <h2 style="margin: 0">维护操作</h2>
      <span class="muted">17 项手动维护入口 · 危险操作需多次确认</span>
    </div>

    <NSpace vertical :size="12" style="margin-top: 12px">
      <!-- 17 张操作卡片网格（2 列响应式） -->
      <NGrid :cols="'1 s:1 m:2'" :x-gap="12" :y-gap="12" responsive="screen">
        <!-- 卡片 1: 图谱维护 -->
        <NGi>
          <OperationCard
            title="图谱维护"
            description="运行节点去重、PageRank 排序与社区检测，并同步对账债务表。数据量较大时建议在低峰期执行。"
            icon="database"
            :confirm-level="1"
            :loading="!!loadingMap.maintain"
            tool-name="lcmg_maintain"
            :last-status="lastResultMap.maintain?.status ?? null"
            :last-details="lastResultMap.maintain?.details ?? null"
            :last-text="lastResultMap.maintain?.text ?? null"
            @execute="executeMaintain"
          >
            <template #extra>
              <!-- gm_maintain 异步化：后台任务进度（轮询 status 快照驱动） -->
              <div v-if="!!loadingMap.maintain || maintainProgress" class="reembed-progress">
                <template v-if="maintainProgress?.progressPercent != null">
                  <NProgress
                    type="line"
                    :percentage="Math.min(100, Math.max(0, Math.round(maintainProgress.progressPercent)))"
                    :indicator-placement="'inside'"
                    :height="14"
                    processing
                    style="max-width: 320px"
                  />
                  <div class="muted" style="font-size: var(--fs-caption); margin-top: 4px; line-height: 1.5">
                    Phase {{ maintainProgress.currentPhase ?? 0 }}/{{ maintainProgress.totalPhases ?? '-' }}
                    <template v-if="maintainProgress.phaseName">· {{ maintainProgress.phaseName }}</template>
                    <span v-if="maintainProgress.lockSkipped" style="color: #d03050">
                      · 维护锁被占用，本次未真正调度
                    </span>
                  </div>
                </template>
                <div v-else-if="!!loadingMap.maintain" class="muted" style="font-size: var(--fs-caption)">
                  正在启动后台维护任务…
                </div>
              </div>
              <OperationRecentHistory :logs="maintainHistory" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 1.5: 系统诊断 -->
        <NGi>
          <OperationCard
            title="系统诊断"
            description="对 lcm.db、qmd MCP、Neo4j、熔断器及健康指标做全栈自检，输出多段 Markdown 报告，便于排查问题。"
            icon="activity"
            :confirm-level="0"
            :loading="!!loadingMap.diagnose"
            tool-name="lcmg_diagnose"
            :last-status="lastResultMap.diagnose?.status ?? null"
            :last-details="lastResultMap.diagnose?.details ?? null"
            :last-text="lastResultMap.diagnose?.text ?? null"
            @execute="executeDiagnose"
          >
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_diagnose')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 2: 触发蒸馏 -->
        <NGi>
          <OperationCard
            title="触发蒸馏"
            description="调用 LLM 将 PENDING 经验批量蒸馏为结构化经验（DISTILLED）。蒸馏失败的经验会自动重试，最多 3 次。"
            icon="flask"
            :confirm-level="0"
            :loading="!!loadingMap.distill"
            tool-name="lcmg_distill"
            :last-status="lastResultMap.distill?.status ?? null"
            :last-details="lastResultMap.distill?.details ?? null"
            :last-text="lastResultMap.distill?.text ?? null"
            @execute="executeDistill"
          >
            <template #form>
              <NFormItem label="单次上限" size="small" :show-feedback="false">
                <NInputNumber
                  v-model:value="distillLimit"
                  :min="1"
                  :max="200"
                  size="small"
                  style="width: 100%"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_distill')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 2.1: 重试失败经验 -->
        <NGi>
          <OperationCard
            title="重试失败经验"
            description="将蒸馏失败的 FAILED 经验重置回 PENDING 并清零重试次数，使其可重新进入蒸馏队列。已耗尽自动重试次数的经验需在此重置后才能再次被处理。"
            icon="refresh"
            :confirm-level="0"
            :loading="!!loadingMap.distill_retry"
            tool-name="lcmg_distill_retry"
            :last-status="lastResultMap.distill_retry?.status ?? null"
            :last-details="lastResultMap.distill_retry?.details ?? null"
            :last-text="lastResultMap.distill_retry?.text ?? null"
            @execute="executeDistillRetry"
          >
            <template #form>
              <NFormItem label="重置范围" size="small" :show-feedback="false">
                <NSelect
                  v-model:value="retryMode"
                  :options="retryModeOptions"
                  size="small"
                  style="width: 100%"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_distill_retry')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 2.5: 经验回溯 -->
        <NGi>
          <OperationCard
            title="经验回溯"
            description="从历史对话中重新提取经验并写入 PENDING 队列，常用于对话记录修复后补建经验。默认跳过已处理过的会话。"
            icon="history"
            :confirm-level="0"
            :loading="!!loadingMap.backfill"
            tool-name="lcmg_backfill"
            :last-status="lastResultMap.backfill?.status ?? null"
            :last-details="lastResultMap.backfill?.details ?? null"
            :last-text="lastResultMap.backfill?.text ?? null"
            @execute="executeBackfill"
          >
            <template #form>
              <NFormItem label="处理会话数" size="small" :show-feedback="false">
                <NInputNumber
                  v-model:value="backfillLimit"
                  :min="1"
                  :max="500"
                  size="small"
                  style="width: 100%"
                />
              </NFormItem>
              <NFormItem label="忽略进度重跑" size="small" :show-feedback="false">
                <NSwitch v-model:value="backfillForce" size="small" />
                <span style="margin-left: 8px; font-size: 12px; color: #999">
                  {{ backfillForce ? '重新处理所有会话' : '跳过已处理会话' }}
                </span>
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_backfill')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 3: 触发 compact -->
        <NGi>
          <OperationCard
            title="触发 compact"
            description="手动触发指定会话的上下文压缩；不指定会话时，自动处理最紧急的债务会话。"
            icon="compress"
            :confirm-level="1"
            :loading="!!loadingMap.compact"
            tool-name="lcmg_compact"
            :last-status="lastResultMap.compact?.status ?? null"
            :last-details="lastResultMap.compact?.details ?? null"
            :last-text="lastResultMap.compact?.text ?? null"
            @execute="executeCompact"
          >
            <template #form>
              <NFormItem label="conversationId（可选）" size="small" :show-feedback="false">
                <NInputNumber
                  v-model:value="compactConversationId"
                  :min="1"
                  size="small"
                  style="width: 100%"
                  placeholder="留空处理最紧急债务"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_compact')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 4: 重置熔断器（危险） -->
        <NGi>
          <OperationCard
            title="重置熔断器"
            description="重置指定子系统的熔断器状态；选择 Neo4j 时，同时清除 GraphAdapter 的连接失败标记。"
            icon="power"
            danger
            :confirm-level="1"
            :loading="!!loadingMap.reset_breaker"
            tool-name="lcmg_reset_breaker"
            :last-status="lastResultMap.reset_breaker?.status ?? null"
            :last-details="lastResultMap.reset_breaker?.details ?? null"
            :last-text="lastResultMap.reset_breaker?.text ?? null"
            @execute="executeResetBreaker"
          >
            <template #form>
              <NFormItem label="子系统" size="small" :show-feedback="false">
                <NSelect
                  v-model:value="breakerName"
                  :options="breakerOptions"
                  size="small"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_reset_breaker')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 5: TTL 清理 -->
        <NGi>
          <OperationCard
            title="TTL 清理"
            description="对账债务表：删除孤儿债务记录，并清理 7 天前的墓碑标记（复用图谱维护能力）。"
            icon="trash"
            :confirm-level="1"
            :loading="!!loadingMap.ttl_cleanup"
            tool-name="lcmg_maintain"
            :last-status="lastResultMap.ttl_cleanup?.status ?? null"
            :last-details="lastResultMap.ttl_cleanup?.details ?? null"
            :last-text="lastResultMap.ttl_cleanup?.text ?? null"
            @execute="executeTtlCleanup"
          >
            <template #extra>
              <OperationRecentHistory :logs="ttlCleanupHistory" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 5.1: 节点置顶（lcmg_pin） -->
        <NGi>
          <OperationCard
            title="节点置顶"
            description="置顶指定图谱节点：置顶节点被排除在 TTL 清理与自动删除之外（长期保留重要知识）。取消置顶后恢复常规 TTL 语义。"
            icon="save"
            :confirm-level="0"
            :loading="!!loadingMap.pin"
            tool-name="lcmg_pin"
            :last-status="lastResultMap.pin?.status ?? null"
            :last-details="lastResultMap.pin?.details ?? null"
            :last-text="lastResultMap.pin?.text ?? null"
            @execute="executePin"
          >
            <template #form>
              <NFormItem label="节点 ID" size="small" :show-feedback="false">
                <NInput v-model:value="pinNodeId" size="small" placeholder="图谱节点 id（可从图谱探索复制）" clearable />
              </NFormItem>
              <NFormItem label="取消置顶 (unpin)" size="small" :show-feedback="false">
                <NSwitch v-model:value="pinUnpin" size="small" />
                <span class="muted" style="margin-left: 8px">
                  {{ pinUnpin ? '取消置顶（恢复 TTL 清理）' : '置顶（豁免 TTL 清理）' }}
                </span>
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_pin')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 5.2: 主动遗忘（lcmg_forget，hard 模式升级为危险 + 三次确认） -->
        <NGi>
          <OperationCard
            title="主动遗忘"
            description="遗忘/废弃指定节点：soft 降低权重（仍可检索），hard 标记 superseded（从检索中排除，不可逆）。需填写节点 ID 或查询词定位目标。"
            icon="trash"
            :danger="forgetDanger"
            :confirm-level="forgetConfirmLevel"
            :loading="!!loadingMap.forget"
            tool-name="lcmg_forget"
            :last-status="lastResultMap.forget?.status ?? null"
            :last-details="lastResultMap.forget?.details ?? null"
            :last-text="lastResultMap.forget?.text ?? null"
            @execute="executeForget"
          >
            <template #form>
              <NFormItem label="节点 ID（可选）" size="small" :show-feedback="false">
                <NInput v-model:value="forgetNodeId" size="small" placeholder="精确指定节点 id；与查询词二选一" clearable />
              </NFormItem>
              <NFormItem label="查询词（可选）" size="small" :show-feedback="false">
                <NInput v-model:value="forgetQuery" size="small" placeholder="按语义定位待遗忘节点（与 ID 二选一）" clearable />
              </NFormItem>
              <NFormItem label="遗忘模式" size="small" :show-feedback="false">
                <NSelect v-model:value="forgetMode" :options="forgetModeOptions" size="small" />
              </NFormItem>
              <NFormItem v-if="forgetMode === 'hard'" label="confirm（硬遗忘必选）" size="small" :show-feedback="false">
                <NSwitch v-model:value="forgetConfirm" size="small" />
                <span class="muted" style="margin-left: 8px">
                  硬遗忘将从检索中排除该节点，不可逆
                </span>
              </NFormItem>
              <NAlert
                v-if="forgetMode === 'hard'"
                type="warning"
                :show-icon="true"
                style="margin-top: 8px"
              >
                硬遗忘不可逆：节点被标记 superseded 后不再参与检索。请确认目标节点无误。
              </NAlert>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_forget')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 6: 备份 -->
        <NGi>
          <OperationCard
            title="备份"
            description="将 Neo4j 图谱、LCM 对话与 memory/*.md 一并导出为单个 JSON 文件。输出路径必须在 ~/.openclaw 目录下。"
            icon="save"
            :confirm-level="0"
            :loading="!!loadingMap.backup"
            tool-name="lcmg_backup"
            :last-status="lastResultMap.backup?.status ?? null"
            :last-details="lastResultMap.backup?.details ?? null"
            :last-text="lastResultMap.backup?.text ?? null"
            @execute="executeBackup"
          >
            <template #banner>
              <!-- P1-4：最近一次备份状态横幅 -->
              <NAlert
                :type="lastBackupLog ? (lastBackupLog.status === 'success' ? 'success' : 'error') : 'info'"
                :show-icon="true"
                style="margin-bottom: 8px"
              >
                <NSpace align="center" :size="6" :wrap="false">
                  <span style="font-weight: 600">最近一次备份</span>
                  <template v-if="lastBackupLog">
                    <NTag
                      :type="lastBackupLog.status === 'success' ? 'success' : 'error'"
                      size="tiny"
                      round
                    >
                      {{ lastBackupLog.status === 'success' ? '成功' : '失败' }}
                    </NTag>
                    <NText depth="3">{{ formatDateTime(lastBackupLog.ts) }}</NText>
                    <NText
                      v-if="backupFilePath(lastBackupLog)"
                      depth="2"
                      code
                      style="font-size: 12px; word-break: break-all"
                    >
                      {{ backupFilePath(lastBackupLog) }}
                    </NText>
                  </template>
                  <NText v-else depth="3">尚未执行过备份</NText>
                </NSpace>
              </NAlert>
            </template>
            <template #form>
              <NFormItem
                label="输出路径（目录）"
                size="small"
                :validation-status="backupPathError ? 'error' : undefined"
                :feedback="backupPathError ?? undefined"
              >
                <NInput
                  v-model:value="backupOutputPath"
                  size="small"
                  placeholder="~/.openclaw/backup-YYYYMMDD"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_backup')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 7: 恢复（危险 + 三次确认 + dryRun 默认 true） -->
        <NGi>
          <OperationCard
            title="恢复"
            description="从备份 JSON 恢复到 Neo4j / LCM / 文件。Neo4j 采用 MERGE 写入，不会删除现有节点；dryRun 默认开启，关闭后才会实际写入。"
            icon="upload"
            danger
            :confirm-level="2"
            :loading="!!loadingMap.restore"
            tool-name="lcmg_restore"
            :last-status="lastResultMap.restore?.status ?? null"
            :last-details="lastResultMap.restore?.details ?? null"
            :last-text="lastResultMap.restore?.text ?? null"
            @execute="executeRestore"
          >
            <template #form>
              <NFormItem
                label="备份文件路径"
                size="small"
                :validation-status="restorePathError ? 'error' : undefined"
                :feedback="restorePathError ?? undefined"
              >
                <NInput
                  v-model:value="restoreBackupPath"
                  size="small"
                  placeholder="~/.openclaw/.../memory-full-backup-*.json"
                />
              </NFormItem>
              <NFormItem label="目标" size="small" :show-feedback="false">
                <NSelect
                  v-model:value="restoreTargets"
                  :options="restoreTargetsOptions"
                  size="small"
                />
              </NFormItem>
              <NFormItem label="dryRun（预览不写入）" size="small" :show-feedback="false">
                <NSwitch v-model:value="restoreDryRun" size="small" />
                <span class="muted" style="margin-left: 8px">
                  默认开启；关闭后才会实际写入数据
                </span>
              </NFormItem>
              <NAlert
                v-if="!restoreDryRun"
                type="warning"
                :show-icon="true"
                style="margin-top: 8px"
              >
                已关闭 dryRun：执行后将实际向 Neo4j / LCM 写入数据。请再次确认备份文件路径正确。
              </NAlert>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_restore')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 8: 同步修复（mode=repair 时升级为危险 + 二次确认） -->
        <NGi>
          <OperationCard
            title="同步修复"
            description="跨存储一致性检查与修复：检测孤儿 Neo4j 节点以及 TTL / pin 状态。repair 模式下会实际删除孤儿节点。"
            icon="refresh"
            :danger="syncDanger"
            :confirm-level="syncConfirmLevel"
            :loading="!!loadingMap.sync"
            tool-name="lcmg_sync"
            :last-status="lastResultMap.sync?.status ?? null"
            :last-details="lastResultMap.sync?.details ?? null"
            :last-text="lastResultMap.sync?.text ?? null"
            @execute="executeSync"
          >
            <template #form>
              <NFormItem label="模式" size="small" :show-feedback="false">
                <NSelect
                  v-model:value="syncMode"
                  :options="syncModeOptions"
                  size="small"
                />
              </NFormItem>
              <NFormItem label="dryRun（预览不写入）" size="small" :show-feedback="false">
                <NSwitch v-model:value="syncDryRun" size="small" />
                <span class="muted" style="margin-left: 8px">
                  默认开启；仅 repair 模式且关闭时才实际删除
                </span>
              </NFormItem>
              <NAlert
                v-if="syncMode === 'repair' && !syncDryRun"
                type="warning"
                :show-icon="true"
                style="margin-top: 8px"
              >
                处于 repair 模式且已关闭 dryRun：执行后将实际删除孤儿节点，该操作不可逆。
              </NAlert>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_sync')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 9: 历史导入 -->
        <NGi>
          <OperationCard
            title="历史导入"
            description="将 LCM 消息、记忆文件或两者一并导入 Neo4j（LLM 实体抽取，未配置时降级直存）。导入完成会自动在后台建立三级节点。"
            icon="download"
            :confirm-level="1"
            :loading="!!loadingMap.import"
            tool-name="lcmg_import"
            :last-status="lastResultMap.import?.status ?? null"
            :last-details="lastResultMap.import?.details ?? null"
            :last-text="lastResultMap.import?.text ?? null"
            @execute="executeImport"
          >
            <template #form>
              <NFormItem label="来源" size="small" :show-feedback="false">
                <NSelect
                  v-model:value="importSource"
                  :options="importSourceOptions"
                  size="small"
                />
              </NFormItem>
              <NFormItem label="单次上限" size="small" :show-feedback="false">
                <NInputNumber
                  v-model:value="importLimit"
                  :min="1"
                  :max="500"
                  size="small"
                  style="width: 100%"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('lcmg_import')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 9.5: 三级节点重建（v2.8.1 新增） -->
        <NGi>
          <OperationCard
            title="三级节点重建"
            description="读取会话消息，按 user / assistant 轮次调用 LLM 提取，批量写入 :Task / :Skill / :Event 三级节点及其边（生产节点，不含 :Benchmark）。按需触发，依据处理进度自动跳过已提取的轮次。"
            icon="share"
            :confirm-level="1"
            :loading="!!loadingMap.extract_rebuild"
            tool-name="gm_pro_extract_rebuild"
            :last-status="lastResultMap.extract_rebuild?.status ?? null"
            :last-details="lastResultMap.extract_rebuild?.details ?? null"
            :last-text="lastResultMap.extract_rebuild?.text ?? null"
            @execute="executeExtractRebuild"
          >
            <template #form>
              <NFormItem label="指定会话" size="small" :show-feedback="false">
                <NInput v-model:value="extractSessionKey" size="small" placeholder="留空则重建全部会话" clearable />
              </NFormItem>
              <NFormItem label="提取模式" size="small" :show-feedback="false">
                <NSelect
                  v-model:value="extractMode"
                  size="small"
                  :options="[
                    { label: 'LLM 提取（默认，精度高）', value: 'llm' },
                    { label: '规则快速提取（heuristic，毫秒级零成本）', value: 'heuristic' },
                  ]"
                />
              </NFormItem>
              <NFormItem label="单次处理轮次" size="small" :show-feedback="false">
                <NInputNumber v-model:value="extractLimit" :min="1" :max="500" size="small" style="width: 100%" />
              </NFormItem>
              <NFormItem label="会话内 LLM 并发窗口" size="small" :show-feedback="false">
                <NInputNumber v-model:value="extractConcurrency" :min="1" :max="128" size="small" style="width: 100%" />
              </NFormItem>
              <NFormItem label="会话并发数（批量）" size="small" :show-feedback="false">
                <NInputNumber v-model:value="extractSessionConcurrency" :min="1" :max="32" size="small" style="width: 100%" />
              </NFormItem>
              <NFormItem label="限制会话数（0 不限制）" size="small" :show-feedback="false">
                <NInputNumber v-model:value="extractLimitSessions" :min="0" :max="100000" size="small" style="width: 100%" />
              </NFormItem>
              <NFormItem label="读取分页大小" size="small" :show-feedback="false">
                <NInputNumber v-model:value="extractPageSize" :min="1" :max="20000" size="small" style="width: 100%" />
              </NFormItem>
              <NFormItem label="合并写入批上限" size="small" :show-feedback="false">
                <NInputNumber v-model:value="extractWriteBatchSize" :min="1" :max="50000" size="small" style="width: 100%" />
              </NFormItem>
              <NFormItem label="进度落盘路径" size="small" :show-feedback="false">
                <NInput v-model:value="extractProgressPath" size="small" placeholder="留空自动区分：单会话→/tmp/rebuild-session.json，全部→/tmp/rebuild-all.json；填入路径即启用断点续传" clearable />
              </NFormItem>
            </template>
            <!-- 重建运行中：批次进度 + 总进度 双进度条（含数量与百分比） -->
            <template #progress>
              <div v-if="extractProgress" class="extract-progress">
                <div class="extract-progress-row">
                  <span class="extract-progress-label">批次进度</span>
                  <NProgress
                    :percentage="extractBatchPercent"
                    :height="8"
                    :show-indicator="false"
                    processing
                    style="flex: 1"
                  />
                  <span class="extract-progress-count">
                    第 {{ extractProgress.currentBatch }} / {{ extractProgress.totalBatches }} 批 · {{ extractBatchPercent }}%
                  </span>
                </div>
                <div class="extract-progress-row">
                  <span class="extract-progress-label">总进度</span>
                  <NProgress
                    :percentage="extractTotalPercent"
                    :height="8"
                    :show-indicator="false"
                    processing
                    style="flex: 1"
                  />
                  <span class="extract-progress-count">
                    轮次 {{ extractProgress.processedTurns }} / {{ extractProgress.totalTurns }}
                    · 会话 {{ extractProgress.currentSession }}/{{ extractProgress.totalSessions }} · {{ extractTotalPercent }}%
                    <span v-if="extractProgress.llmOutputTokens !== undefined" class="extract-token">
                      · LLM 输出 {{ extractProgress.llmOutputTokens }} tok
                    </span>
                  </span>
                </div>
                <!-- v2.4.1: 失败会话数 + 续传提示 -->
                <div v-if="(extractProgress.failedSessions ?? 0) > 0 || extractProgress.message" class="extract-progress-failed">
                  <span v-if="(extractProgress.failedSessions ?? 0) > 0" class="extract-failed-badge">
                    ⚠ 失败会话 {{ extractProgress.failedSessions }}
                  </span>
                  <span v-if="extractProgress.message">{{ extractProgress.message }}</span>
                  <span class="extract-failed-tip">
                    可沿原进度路径重新触发，断点文件已累计失败数，失败会话未标记 -1、会自动重试。
                  </span>
                </div>
              </div>
              <div v-else class="extract-progress-waiting">
                {{ extractSessionKey?.trim() ? '正在执行单会话重建…' : '已提交异步重建任务，正在收集进度…' }}
              </div>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('gm_pro_extract_rebuild')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 10: Bootstrap 反馈（v2.3.5 新增） -->
        <NGi>
          <OperationCard
            title="Bootstrap 反馈"
            description="针对「图谱已有历史节点但零反馈」的冷启动场景，以节点 name 作为 query 和 reply 合成 warmup 反馈，一次性喂入 N 条快速突破冷启动。"
            icon="zap"
            :confirm-level="1"
            :loading="!!loadingMap.bootstrap"
            tool-name="gm_bootstrap"
            :last-status="lastResultMap.bootstrap?.status ?? null"
            :last-details="lastResultMap.bootstrap?.details ?? null"
            :last-text="lastResultMap.bootstrap?.text ?? null"
            @execute="executeBootstrap"
          >
            <template #form>
              <NFormItem label="合成条数" size="small" :show-feedback="false">
                <NInputNumber
                  v-model:value="bootstrapLimit"
                  :min="1"
                  :max="500"
                  size="small"
                  style="width: 100%"
                />
              </NFormItem>
            </template>
            <template #extra>
              <OperationRecentHistory :logs="historyOf('gm_bootstrap')" />
            </template>
          </OperationCard>
        </NGi>

        <!-- 卡片 11: 重新向量化（gm-pro，v2.8.0 新增） -->
        <NGi>
          <OperationCard
            title="重新向量化"
            description="为图谱全部节点重新生成 embedding。开启「清库重导」会先清空节点库再重向量化（clear=true），推荐流程：清库重导 → 导入数据 → 重新向量化（埋点）。消耗大量 embedding 配额。"
            icon="refresh"
            :danger="reembedClear"
            :confirm-level="reembedClear ? 2 : 1"
            :loading="!!loadingMap.reembed"
            tool-name="gm_reembed"
            :last-status="lastResultMap.reembed?.status ?? null"
            :last-details="lastResultMap.reembed?.details ?? null"
            :last-text="lastResultMap.reembed?.text ?? null"
            @execute="executeReembed"
          >
            <template #form>
              <NFormItem label="清库重导 (clear=true)" size="small" :show-feedback="false">
                <NSwitch v-model:value="reembedClear" size="small" />
              </NFormItem>
            </template>
            <template #extra>
              <!-- gm_reembed 异步化：后台任务进度（轮询 status 快照驱动） -->
              <div v-if="!!loadingMap.reembed || reembedProgress" class="reembed-progress">
                <template v-if="reembedProgress?.progressPercent != null">
                  <NProgress
                    type="line"
                    :percentage="Math.min(100, Math.max(0, Math.round(reembedProgress.progressPercent)))"
                    :indicator-placement="'inside'"
                    :height="14"
                    processing
                    style="max-width: 320px"
                  />
                  <div class="muted" style="font-size: var(--fs-caption); margin-top: 4px; line-height: 1.5">
                    批次 {{ reembedProgress.currentBatch ?? 0 }}/{{ reembedProgress.totalBatches ?? '-' }} ·
                    进度 {{ reembedProgress.processedNodes ?? 0 }}/{{ reembedProgress.totalNodes ?? '-' }} 节点 ·
                    成功 {{ reembedProgress.reEmbedded ?? 0 }} ·
                    <span v-if="(reembedProgress.failed ?? 0) > 0" style="color: #d03050">失败 {{ reembedProgress.failed }}</span>
                    <span v-else>失败 0</span>
                    <template v-if="reembedProgress.etaMs != null">
                      · 剩余约 {{ Math.ceil(reembedProgress.etaMs / 1000) }}s
                    </template>
                  </div>
                </template>
                <div v-else-if="!!loadingMap.reembed" class="muted" style="font-size: var(--fs-caption)">
                  正在启动后台重向量化任务…
                </div>
              </div>
              <OperationRecentHistory :logs="historyOf('gm_reembed')" />
            </template>
          </OperationCard>
        </NGi>

        </NGrid>

      <!-- M14 修复：顶部错误兜底提示（友好文案 + 可关闭） -->
      <NAlert
        v-if="mutation.isError.value && !topErrorDismissed"
        type="error"
        :show-icon="true"
        title="操作执行失败"
        closable
        @close="topErrorDismissed = true"
      >
        <NSpace vertical :size="4">
          <span>{{ mutation.error.value?.message ?? '未知错误' }}</span>
          <span class="muted">请检查后端 MCP 服务是否正常，或查看下方操作日志了解详情。可稍后重试该操作。</span>
        </NSpace>
      </NAlert>

      <!-- 操作日志区（底部固定） -->
      <OperationLog :logs="logs" @clear="logs = []" />
    </NSpace>
  </div>
</template>

<style scoped>
.maintain-view {
  width: 100%;
}
.maintain-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
}
.muted {
  /* color 由 tokens.css 全局 .muted 提供，此处仅追加 caption 字号 */
  font-size: var(--fs-caption);
}
/* 三级节点重建双进度条 */
.extract-progress {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px;
  background: var(--color-surface-2);
  border-radius: var(--radius-sm);
}
.extract-progress-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.extract-progress-label {
  flex: 0 0 auto;
  min-width: 52px;
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
}
.extract-progress-count {
  flex: 0 0 auto;
  font-size: var(--fs-caption);
  color: var(--color-text-secondary);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.extract-progress-waiting {
  font-size: var(--fs-caption);
  color: var(--color-text-tertiary);
}
.extract-progress-failed {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 6px;
  padding: 6px 10px;
  background: var(--color-warning-soft, #fff7e6);
  border: 1px solid var(--color-warning-border, #ffd591);
  border-radius: var(--radius-sm);
  font-size: var(--fs-caption);
  color: var(--color-warning-text, #d46b08);
}
.extract-failed-badge {
  font-weight: 600;
  flex: 0 0 auto;
}
.extract-failed-tip {
  color: var(--color-text-secondary);
  flex: 1 1 auto;
  min-width: 0;
}
</style>
