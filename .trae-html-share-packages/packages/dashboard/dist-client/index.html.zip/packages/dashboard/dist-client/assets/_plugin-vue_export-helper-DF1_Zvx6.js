import{o as so,bU as io,bu as c,c as ho,b as f,l as m,W as z,a as I,M as U,bm as go,d as uo,e as L,v as bo,f as Co,a4 as vo,g,bp as fo,x as D,K as po}from"./index-DOdUsA7z.js";import{f as ko,g as x,r as mo,e as W,z as xo,B as yo}from"./vue-Droa3b3F.js";function _o(o,e="default",r=[]){const a=o.$slots[e];return a===void 0?r:a()}function Po(o){const{textColor2:e,primaryColorHover:r,primaryColorPressed:i,primaryColor:a,infoColor:n,successColor:t,warningColor:d,errorColor:h,baseColor:p,borderColor:k,opacityDisabled:b,tagColor:T,closeIconColor:P,closeIconColorHover:v,closeIconColorPressed:l,borderRadiusSmall:s,fontSizeMini:C,fontSizeTiny:u,fontSizeSmall:$,fontSizeMedium:B,heightMini:E,heightTiny:w,heightSmall:M,heightMedium:H,closeColorHover:_,closeColorPressed:R,buttonColor2Hover:O,buttonColor2Pressed:j,fontWeightStrong:A}=o;return Object.assign(Object.assign({},io),{closeBorderRadius:s,heightTiny:E,heightSmall:w,heightMedium:M,heightLarge:H,borderRadius:s,opacityDisabled:b,fontSizeTiny:C,fontSizeSmall:u,fontSizeMedium:$,fontSizeLarge:B,fontWeightStrong:A,textColorCheckable:e,textColorHoverCheckable:e,textColorPressedCheckable:e,textColorChecked:p,colorCheckable:"#0000",colorHoverCheckable:O,colorPressedCheckable:j,colorChecked:a,colorCheckedHover:r,colorCheckedPressed:i,border:`1px solid ${k}`,textColor:e,color:T,colorBordered:"rgb(250, 250, 252)",closeIconColor:P,closeIconColorHover:v,closeIconColorPressed:l,closeColorHover:_,closeColorPressed:R,borderPrimary:`1px solid ${c(a,{alpha:.3})}`,textColorPrimary:a,colorPrimary:c(a,{alpha:.12}),colorBorderedPrimary:c(a,{alpha:.1}),closeIconColorPrimary:a,closeIconColorHoverPrimary:a,closeIconColorPressedPrimary:a,closeColorHoverPrimary:c(a,{alpha:.12}),closeColorPressedPrimary:c(a,{alpha:.18}),borderInfo:`1px solid ${c(n,{alpha:.3})}`,textColorInfo:n,colorInfo:c(n,{alpha:.12}),colorBorderedInfo:c(n,{alpha:.1}),closeIconColorInfo:n,closeIconColorHoverInfo:n,closeIconColorPressedInfo:n,closeColorHoverInfo:c(n,{alpha:.12}),closeColorPressedInfo:c(n,{alpha:.18}),borderSuccess:`1px solid ${c(t,{alpha:.3})}`,textColorSuccess:t,colorSuccess:c(t,{alpha:.12}),colorBorderedSuccess:c(t,{alpha:.1}),closeIconColorSuccess:t,closeIconColorHoverSuccess:t,closeIconColorPressedSuccess:t,closeColorHoverSuccess:c(t,{alpha:.12}),closeColorPressedSuccess:c(t,{alpha:.18}),borderWarning:`1px solid ${c(d,{alpha:.35})}`,textColorWarning:d,colorWarning:c(d,{alpha:.15}),colorBorderedWarning:c(d,{alpha:.12}),closeIconColorWarning:d,closeIconColorHoverWarning:d,closeIconColorPressedWarning:d,closeColorHoverWarning:c(d,{alpha:.12}),closeColorPressedWarning:c(d,{alpha:.18}),borderError:`1px solid ${c(h,{alpha:.23})}`,textColorError:h,colorError:c(h,{alpha:.1}),colorBorderedError:c(h,{alpha:.08}),closeIconColorError:h,closeIconColorHoverError:h,closeIconColorPressedError:h,closeColorHoverError:c(h,{alpha:.12}),closeColorPressedError:c(h,{alpha:.18})})}const So={common:so,self:Po},zo={color:Object,type:{type:String,default:"default"},round:Boolean,size:String,closable:Boolean,disabled:{type:Boolean,default:void 0}},Io=ho("tag",`
 --n-close-margin: var(--n-close-margin-top) var(--n-close-margin-right) var(--n-close-margin-bottom) var(--n-close-margin-left);
 white-space: nowrap;
 position: relative;
 box-sizing: border-box;
 cursor: default;
 display: inline-flex;
 align-items: center;
 flex-wrap: nowrap;
 padding: var(--n-padding);
 border-radius: var(--n-border-radius);
 color: var(--n-text-color);
 background-color: var(--n-color);
 transition: 
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 line-height: 1;
 height: var(--n-height);
 font-size: var(--n-font-size);
`,[f("strong",`
 font-weight: var(--n-font-weight-strong);
 `),m("border",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 border: var(--n-border);
 transition: border-color .3s var(--n-bezier);
 `),m("icon",`
 display: flex;
 margin: 0 4px 0 0;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 font-size: var(--n-avatar-size-override);
 `),m("avatar",`
 display: flex;
 margin: 0 6px 0 0;
 `),m("close",`
 margin: var(--n-close-margin);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),f("round",`
 padding: 0 calc(var(--n-height) / 3);
 border-radius: calc(var(--n-height) / 2);
 `,[m("icon",`
 margin: 0 4px 0 calc((var(--n-height) - 8px) / -2);
 `),m("avatar",`
 margin: 0 6px 0 calc((var(--n-height) - 8px) / -2);
 `),f("closable",`
 padding: 0 calc(var(--n-height) / 4) 0 calc(var(--n-height) / 3);
 `)]),f("icon, avatar",[f("round",`
 padding: 0 calc(var(--n-height) / 3) 0 calc(var(--n-height) / 2);
 `)]),f("disabled",`
 cursor: not-allowed !important;
 opacity: var(--n-opacity-disabled);
 `),f("checkable",`
 cursor: pointer;
 box-shadow: none;
 color: var(--n-text-color-checkable);
 background-color: var(--n-color-checkable);
 `,[z("disabled",[I("&:hover","background-color: var(--n-color-hover-checkable);",[z("checked","color: var(--n-text-color-hover-checkable);")]),I("&:active","background-color: var(--n-color-pressed-checkable);",[z("checked","color: var(--n-text-color-pressed-checkable);")])]),f("checked",`
 color: var(--n-text-color-checked);
 background-color: var(--n-color-checked);
 `,[z("disabled",[I("&:hover","background-color: var(--n-color-checked-hover);"),I("&:active","background-color: var(--n-color-checked-pressed);")])])])]),To=Object.assign(Object.assign(Object.assign({},L.props),zo),{bordered:{type:Boolean,default:void 0},checked:Boolean,checkable:Boolean,strong:Boolean,triggerClickOnClose:Boolean,onClose:[Array,Function],onMouseenter:Function,onMouseleave:Function,"onUpdate:checked":Function,onUpdateChecked:Function,internalCloseFocusable:{type:Boolean,default:!0},internalCloseIsButtonTag:{type:Boolean,default:!0},onCheckedChange:Function}),$o=po("n-tag"),Ro=ko({name:"Tag",props:To,slots:Object,setup(o){const e=mo(null),{mergedBorderedRef:r,mergedClsPrefixRef:i,inlineThemeDisabled:a,mergedRtlRef:n,mergedComponentPropsRef:t}=uo(o),d=W(()=>{var l,s;return o.size||((s=(l=t==null?void 0:t.value)===null||l===void 0?void 0:l.Tag)===null||s===void 0?void 0:s.size)||"medium"}),h=L("Tag","-tag",Io,So,o,i);xo($o,{roundRef:yo(o,"round")});function p(){if(!o.disabled&&o.checkable){const{checked:l,onCheckedChange:s,onUpdateChecked:C,"onUpdate:checked":u}=o;C&&C(!l),u&&u(!l),s&&s(!l)}}function k(l){if(o.triggerClickOnClose||l.stopPropagation(),!o.disabled){const{onClose:s}=o;s&&vo(s,l)}}const b={setTextContent(l){const{value:s}=e;s&&(s.textContent=l)}},T=bo("Tag",n,i),P=W(()=>{const{type:l,color:{color:s,textColor:C}={}}=o,u=d.value,{common:{cubicBezierEaseInOut:$},self:{padding:B,closeMargin:E,borderRadius:w,opacityDisabled:M,textColorCheckable:H,textColorHoverCheckable:_,textColorPressedCheckable:R,textColorChecked:O,colorCheckable:j,colorHoverCheckable:A,colorPressedCheckable:K,colorChecked:V,colorCheckedHover:X,colorCheckedPressed:G,closeBorderRadius:q,fontWeightStrong:J,[g("colorBordered",l)]:Q,[g("closeSize",u)]:Y,[g("closeIconSize",u)]:Z,[g("fontSize",u)]:oo,[g("height",u)]:N,[g("color",l)]:eo,[g("textColor",l)]:ro,[g("border",l)]:lo,[g("closeIconColor",l)]:F,[g("closeIconColorHover",l)]:ao,[g("closeIconColorPressed",l)]:co,[g("closeColorHover",l)]:no,[g("closeColorPressed",l)]:to}}=h.value,S=fo(E);return{"--n-font-weight-strong":J,"--n-avatar-size-override":`calc(${N} - 8px)`,"--n-bezier":$,"--n-border-radius":w,"--n-border":lo,"--n-close-icon-size":Z,"--n-close-color-pressed":to,"--n-close-color-hover":no,"--n-close-border-radius":q,"--n-close-icon-color":F,"--n-close-icon-color-hover":ao,"--n-close-icon-color-pressed":co,"--n-close-icon-color-disabled":F,"--n-close-margin-top":S.top,"--n-close-margin-right":S.right,"--n-close-margin-bottom":S.bottom,"--n-close-margin-left":S.left,"--n-close-size":Y,"--n-color":s||(r.value?Q:eo),"--n-color-checkable":j,"--n-color-checked":V,"--n-color-checked-hover":X,"--n-color-checked-pressed":G,"--n-color-hover-checkable":A,"--n-color-pressed-checkable":K,"--n-font-size":oo,"--n-height":N,"--n-opacity-disabled":M,"--n-padding":B,"--n-text-color":C||ro,"--n-text-color-checkable":H,"--n-text-color-checked":O,"--n-text-color-hover-checkable":_,"--n-text-color-pressed-checkable":R}}),v=a?Co("tag",W(()=>{let l="";const{type:s,color:{color:C,textColor:u}={}}=o;return l+=s[0],l+=d.value[0],C&&(l+=`a${D(C)}`),u&&(l+=`b${D(u)}`),r.value&&(l+="c"),l}),P,o):void 0;return Object.assign(Object.assign({},b),{rtlEnabled:T,mergedClsPrefix:i,contentRef:e,mergedBordered:r,handleClick:p,handleCloseClick:k,cssVars:a?void 0:P,themeClass:v==null?void 0:v.themeClass,onRender:v==null?void 0:v.onRender})},render(){var o,e;const{mergedClsPrefix:r,rtlEnabled:i,closable:a,color:{borderColor:n}={},round:t,onRender:d,$slots:h}=this;d==null||d();const p=U(h.avatar,b=>b&&x("div",{class:`${r}-tag__avatar`},b)),k=U(h.icon,b=>b&&x("div",{class:`${r}-tag__icon`},b));return x("div",{class:[`${r}-tag`,this.themeClass,{[`${r}-tag--rtl`]:i,[`${r}-tag--strong`]:this.strong,[`${r}-tag--disabled`]:this.disabled,[`${r}-tag--checkable`]:this.checkable,[`${r}-tag--checked`]:this.checkable&&this.checked,[`${r}-tag--round`]:t,[`${r}-tag--avatar`]:p,[`${r}-tag--icon`]:k,[`${r}-tag--closable`]:a}],style:this.cssVars,onClick:this.handleClick,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},k||p,x("span",{class:`${r}-tag__content`,ref:"contentRef"},(e=(o=this.$slots).default)===null||e===void 0?void 0:e.call(o)),!this.checkable&&a?x(go,{clsPrefix:r,class:`${r}-tag__close`,disabled:this.disabled,onClick:this.handleCloseClick,focusable:this.internalCloseFocusable,round:t,isButtonTag:this.internalCloseIsButtonTag,absolute:!0}):null,!this.checkable&&this.mergedBordered?x("div",{class:`${r}-tag__border`,style:{borderColor:n}}):null)}});class Bo extends Error{constructor(e,r,i){super(e),this.status=r,this.path=i,this.name="ApiError"}}function Eo(o){if(!(o instanceof Error))return!1;if(o.name==="AbortError"||o instanceof TypeError)return!0;const e=o.message.toLowerCase();return e.includes("failed to fetch")||e.includes("networkerror")||e.includes("fetch failed")}async function wo(o,e){let i=null;for(let a=1;a<=4;a++)try{return await o()}catch(n){if(i=n,!Eo(n)||a===4)throw n;const t=200*Math.pow(2,a-1);console.debug(`[api-client] ${e} transient network error, retry ${a}/3 in ${t}ms`),await new Promise(d=>setTimeout(d,t))}throw i}async function y(o,e,r){return wo(async()=>{const i={accept:"application/json"},a={method:o,headers:i};r!==void 0&&(i["content-type"]="application/json",a.body=JSON.stringify(r));const n=await fetch(e,a);if(!n.ok){let t="";try{t=await n.text()}catch{}throw new Bo(`${o} ${e} 失败: HTTP ${n.status}${t?` - ${t}`:""}`,n.status,e)}return await n.json()},`${o} ${e}`)}async function Oo(o){return y("GET",o)}async function jo(o,e){return y("POST",o,e??{})}async function Ao(o,e){return y("PATCH",o,e??{})}async function Wo(o,e){return y("PUT",o,e??{})}async function No(o){return y("DELETE",o)}const Fo=(o,e)=>{const r=o.__vccOpts||o;for(const[i,a]of e)r[i]=a;return r};export{Bo as A,Ro as N,Fo as _,Oo as a,jo as b,No as c,Ao as d,Wo as e,_o as g};
