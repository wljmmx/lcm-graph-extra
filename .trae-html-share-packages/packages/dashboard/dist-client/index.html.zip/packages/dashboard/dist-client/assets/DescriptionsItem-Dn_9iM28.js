import{a as p,c as e,W as V,b as z,l as B,aD as F,aE as G,ap as H,ak as W,d as K,e as E,f as Q,aQ as q,aR as J,g as j}from"./index-C1PDVNBT.js";import{g as U}from"./_plugin-vue_export-helper-jZseSa4X.js";import{f as L,g as n,e as k}from"./vue-Droa3b3F.js";function M(t,g="default",d=[]){const{children:s}=t;if(s!==null&&typeof s=="object"&&!Array.isArray(s)){const i=s[g];if(typeof i=="function")return i()}return d}const X=p([e("descriptions",{fontSize:"var(--n-font-size)"},[e("descriptions-separator",`
 display: inline-block;
 margin: 0 8px 0 2px;
 `),e("descriptions-table-wrapper",[e("descriptions-table",[e("descriptions-table-row",[e("descriptions-table-header",{padding:"var(--n-th-padding)"}),e("descriptions-table-content",{padding:"var(--n-td-padding)"})])])]),V("bordered",[e("descriptions-table-wrapper",[e("descriptions-table",[e("descriptions-table-row",[p("&:last-child",[e("descriptions-table-content",{paddingBottom:0})])])])])]),z("left-label-placement",[e("descriptions-table-content",[p("> *",{verticalAlign:"top"})])]),z("left-label-align",[p("th",{textAlign:"left"})]),z("center-label-align",[p("th",{textAlign:"center"})]),z("right-label-align",[p("th",{textAlign:"right"})]),z("bordered",[e("descriptions-table-wrapper",`
 border-radius: var(--n-border-radius);
 overflow: hidden;
 background: var(--n-merged-td-color);
 border: 1px solid var(--n-merged-border-color);
 `,[e("descriptions-table",[e("descriptions-table-row",[p("&:not(:last-child)",[e("descriptions-table-content",{borderBottom:"1px solid var(--n-merged-border-color)"}),e("descriptions-table-header",{borderBottom:"1px solid var(--n-merged-border-color)"})]),e("descriptions-table-header",`
 font-weight: 400;
 background-clip: padding-box;
 background-color: var(--n-merged-th-color);
 `,[p("&:not(:last-child)",{borderRight:"1px solid var(--n-merged-border-color)"})]),e("descriptions-table-content",[p("&:not(:last-child)",{borderRight:"1px solid var(--n-merged-border-color)"})])])])])]),e("descriptions-header",`
 font-weight: var(--n-th-font-weight);
 font-size: 18px;
 transition: color .3s var(--n-bezier);
 line-height: var(--n-line-height);
 margin-bottom: 16px;
 color: var(--n-title-text-color);
 `),e("descriptions-table-wrapper",`
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[e("descriptions-table",`
 width: 100%;
 border-collapse: separate;
 border-spacing: 0;
 box-sizing: border-box;
 `,[e("descriptions-table-row",`
 box-sizing: border-box;
 transition: border-color .3s var(--n-bezier);
 `,[e("descriptions-table-header",`
 font-weight: var(--n-th-font-weight);
 line-height: var(--n-line-height);
 display: table-cell;
 box-sizing: border-box;
 color: var(--n-th-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),e("descriptions-table-content",`
 vertical-align: top;
 line-height: var(--n-line-height);
 display: table-cell;
 box-sizing: border-box;
 color: var(--n-td-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[B("content",`
 transition: color .3s var(--n-bezier);
 display: inline-block;
 color: var(--n-td-text-color);
 `)]),B("label",`
 font-weight: var(--n-th-font-weight);
 transition: color .3s var(--n-bezier);
 display: inline-block;
 margin-right: 14px;
 color: var(--n-th-text-color);
 `)])])])]),e("descriptions-table-wrapper",`
 --n-merged-th-color: var(--n-th-color);
 --n-merged-td-color: var(--n-td-color);
 --n-merged-border-color: var(--n-border-color);
 `),F(e("descriptions-table-wrapper",`
 --n-merged-th-color: var(--n-th-color-modal);
 --n-merged-td-color: var(--n-td-color-modal);
 --n-merged-border-color: var(--n-border-color-modal);
 `)),G(e("descriptions-table-wrapper",`
 --n-merged-th-color: var(--n-th-color-popover);
 --n-merged-td-color: var(--n-td-color-popover);
 --n-merged-border-color: var(--n-border-color-popover);
 `))]),N="DESCRIPTION_ITEM_FLAG";function Y(t){return typeof t=="object"&&t&&!Array.isArray(t)?t.type&&t.type[N]:!1}const Z=Object.assign(Object.assign({},E.props),{title:String,column:{type:Number,default:3},columns:Number,labelPlacement:{type:String,default:"top"},labelAlign:{type:String,default:"left"},separator:{type:String,default:":"},size:String,bordered:Boolean,labelClass:String,labelStyle:[Object,String],contentClass:String,contentStyle:[Object,String]}),ne=L({name:"Descriptions",props:Z,slots:Object,setup(t){const{mergedClsPrefixRef:g,inlineThemeDisabled:d,mergedComponentPropsRef:s}=K(t),i=k(()=>{var l,a;return t.size||((a=(l=s==null?void 0:s.value)===null||l===void 0?void 0:l.Descriptions)===null||a===void 0?void 0:a.size)||"medium"}),h=E("Descriptions","-descriptions",X,J,t,g),$=k(()=>{const{bordered:l}=t,a=i.value,{common:{cubicBezierEaseInOut:A},self:{titleTextColor:r,thColor:P,thColorModal:v,thColorPopover:R,thTextColor:I,thFontWeight:T,tdTextColor:D,tdColor:o,tdColorModal:f,tdColorPopover:O,borderColor:c,borderColorModal:m,borderColorPopover:y,borderRadius:w,lineHeight:u,[j("fontSize",a)]:S,[j(l?"thPaddingBordered":"thPadding",a)]:x,[j(l?"tdPaddingBordered":"tdPadding",a)]:C}}=h.value;return{"--n-title-text-color":r,"--n-th-padding":x,"--n-td-padding":C,"--n-font-size":S,"--n-bezier":A,"--n-th-font-weight":T,"--n-line-height":u,"--n-th-text-color":I,"--n-td-text-color":D,"--n-th-color":P,"--n-th-color-modal":v,"--n-th-color-popover":R,"--n-td-color":o,"--n-td-color-modal":f,"--n-td-color-popover":O,"--n-border-radius":w,"--n-border-color":c,"--n-border-color-modal":m,"--n-border-color-popover":y}}),b=d?Q("descriptions",k(()=>{let l="";const{bordered:a}=t;return a&&(l+="a"),l+=i.value[0],l}),$,t):void 0;return{mergedClsPrefix:g,cssVars:d?void 0:$,themeClass:b==null?void 0:b.themeClass,onRender:b==null?void 0:b.onRender,compitableColumn:q(t,["columns","column"]),inlineThemeDisabled:d,mergedSize:i}},render(){const t=this.$slots.default,g=t?H(t()):[];g.length;const{contentClass:d,labelClass:s,compitableColumn:i,labelPlacement:h,labelAlign:$,mergedSize:b,bordered:l,title:a,cssVars:A,mergedClsPrefix:r,separator:P,onRender:v}=this;v==null||v();const R=g.filter(o=>Y(o)),I={span:0,row:[],secondRow:[],rows:[]},D=R.reduce((o,f,O)=>{const c=f.props||{},m=R.length-1===O,y=["label"in c?c.label:M(f,"label")],w=[M(f)],u=c.span||1,S=o.span;o.span+=u;const x=c.labelStyle||c["label-style"]||this.labelStyle,C=c.contentStyle||c["content-style"]||this.contentStyle;if(h==="left")l?o.row.push(n("th",{class:[`${r}-descriptions-table-header`,s],colspan:1,style:x},y),n("td",{class:[`${r}-descriptions-table-content`,d],colspan:m?(i-S)*2+1:u*2-1,style:C},w)):o.row.push(n("td",{class:`${r}-descriptions-table-content`,colspan:m?(i-S)*2:u*2},n("span",{class:[`${r}-descriptions-table-content__label`,s],style:x},[...y,P&&n("span",{class:`${r}-descriptions-separator`},P)]),n("span",{class:[`${r}-descriptions-table-content__content`,d],style:C},w)));else{const _=m?(i-S)*2:u*2;o.row.push(n("th",{class:[`${r}-descriptions-table-header`,s],colspan:_,style:x},y)),o.secondRow.push(n("td",{class:[`${r}-descriptions-table-content`,d],colspan:_,style:C},w))}return(o.span>=i||m)&&(o.span=0,o.row.length&&(o.rows.push(o.row),o.row=[]),h!=="left"&&o.secondRow.length&&(o.rows.push(o.secondRow),o.secondRow=[])),o},I).rows.map(o=>n("tr",{class:`${r}-descriptions-table-row`},o));return n("div",{style:A,class:[`${r}-descriptions`,this.themeClass,`${r}-descriptions--${h}-label-placement`,`${r}-descriptions--${$}-label-align`,`${r}-descriptions--${b}-size`,l&&`${r}-descriptions--bordered`]},a||this.$slots.header?n("div",{class:`${r}-descriptions-header`},a||U(this,"header")):null,n("div",{class:`${r}-descriptions-table-wrapper`},n("table",{class:`${r}-descriptions-table`},n("tbody",null,h==="top"&&n("tr",{class:`${r}-descriptions-table-row`,style:{visibility:"collapse"}},W(i*2,n("td",null))),D))))}}),ee={label:String,span:{type:Number,default:1},labelClass:String,labelStyle:[Object,String],contentClass:String,contentStyle:[Object,String]},le=L({name:"DescriptionsItem",[N]:!0,props:ee,slots:Object,render(){return null}});export{ne as N,le as a};
