import{o as _,a as v,c as w,ak as E,d as H,e as z,g as O,al as p}from"./index-DOdUsA7z.js";import{u as j}from"./use-houdini-D7nFSGOV.js";import{f as A,g as k,I as F,F as I,e as y}from"./vue-Droa3b3F.js";function L(e){const{heightSmall:a,heightMedium:n,heightLarge:s,borderRadius:i}=e;return{color:"#eee",colorEnd:"#ddd",borderRadius:i,heightSmall:a,heightMedium:n,heightLarge:s}}const T={common:_,self:L},$=v([w("skeleton",`
 height: 1em;
 width: 100%;
 transition:
 --n-color-start .3s var(--n-bezier),
 --n-color-end .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 animation: 2s skeleton-loading infinite cubic-bezier(0.36, 0, 0.64, 1);
 background-color: var(--n-color-start);
 `),v("@keyframes skeleton-loading",`
 0% {
 background: var(--n-color-start);
 }
 40% {
 background: var(--n-color-end);
 }
 80% {
 background: var(--n-color-start);
 }
 100% {
 background: var(--n-color-start);
 }
 `)]),K=Object.assign(Object.assign({},z.props),{text:Boolean,round:Boolean,circle:Boolean,height:[String,Number],width:[String,Number],size:String,repeat:{type:Number,default:1},animated:{type:Boolean,default:!0},sharp:{type:Boolean,default:!0}}),q=A({name:"Skeleton",inheritAttrs:!1,props:K,setup(e){j();const{mergedClsPrefixRef:a,mergedComponentPropsRef:n}=H(e),s=y(()=>{var o,t;return e.size||((t=(o=n==null?void 0:n.value)===null||o===void 0?void 0:o.Skeleton)===null||t===void 0?void 0:t.size)}),i=z("Skeleton","-skeleton",$,T,e,a);return{mergedClsPrefix:a,style:y(()=>{var o,t;const g=i.value,{common:{cubicBezierEaseInOut:S}}=g,h=g.self,{color:x,colorEnd:B,borderRadius:P}=h;let l;const{circle:d,sharp:R,round:C,width:r,height:c,text:f,animated:N}=e,b=s.value;b!==void 0&&(l=h[O("height",b)]);const u=d?(o=r??c)!==null&&o!==void 0?o:l:r,m=(t=d?r??c:c)!==null&&t!==void 0?t:l;return{display:f?"inline-block":"",verticalAlign:f?"-0.125em":"",borderRadius:d?"50%":C?"4096px":R?"":P,width:typeof u=="number"?p(u):u,height:typeof m=="number"?p(m):m,animation:N?"":"none","--n-bezier":S,"--n-color-start":x,"--n-color-end":B}})}},render(){const{repeat:e,style:a,mergedClsPrefix:n,$attrs:s}=this,i=k("div",F({class:`${n}-skeleton`,style:a},s));return e>1?k(I,null,E(e,null).map(o=>[i,`
`])):i}});export{q as N};
